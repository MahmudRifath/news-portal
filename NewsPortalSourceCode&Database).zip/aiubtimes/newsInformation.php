<?php 
/*
	include("dbConnection.php");
	
	$sql='select * FROM news_info,newsarticle WHERE news_info.N_A_no = newsarticle.editorNo order by newsarticle.submissionDate DESC';
	
	$result=queryDb($sql);
	
	while($row=mysqli_fetch_assoc($result))
	{
		echo $row["firstName"]." ".$row["lastName"]."</br>";
	}
*/

?>

<?php

		session_start();
		if(isset($_SESSION['user']) && isset($_SESSION["admin"]))
		{	
			if(!$_SESSION['user']=='valid' && !$_SESSION["admin"] ){
				header("location:signin.php");
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{
			header("location:signin.php");
		}
?>


<html>
<head>
<style>
	input{
		
		width:100px;
		height:30px;
	
	}
	select{
		width:100px;
		height:30px;
	}
	#newsInfoTable{
		margin:0px 0px 0px 0px; 
	}
	#newsInfoTable td{
		margin-bottom:2px;
		margin-top:4px;
		text-align: center;
		padding-left:5px;
		padding-top:0px;
		//border-bottom:1px dashed black;
		background:#e4e4e4eb;
	}
	.newsform{
	margin-right:0px;	
	}
	.contentdiv{
		background:white;
		cursor:pointer;
		height:30px;
		margin:0;
		width:100px;
		resize: both;
		word-wrap:break-word;
		overflow: hidden;
		//z-index:-2;
		border:1px dotted gray;
		padding:5px;
	}
	.reportdiv{
			text-align:left;
			background:white;
			cursor:pointer;
			height:30px;
			margin:0;
			width:100px;
			resize: both;
			word-wrap:break-word;
			overflow: hidden;
			//z-index:-2;
			border:1px dotted gray;
			padding:5px;
		}
		
	#newsInfoTable th{
		background:#6e6e6e;
		color:white;
		height:40px;
		//margin-bottom:20px;
		
	}
</style>

</head>
<body>

				<?php
					
					include("dbConnection.php");

					if(isset($_REQUEST["news"]) && isset($_REQUEST["deleted"]))
					{
						queryDb("UPDATE `newsarticle` SET deleted=".$_REQUEST["deleted"]." where N_A_no=".$_REQUEST["news"]);
						//echo "UPDATE `newsarticle` SET deleted=".$_REQUEST["deleted"]." where N_A_no=".$_REQUEST["news"];
					}
					
					
					$result=queryDb('select * FROM user_info,newsarticle WHERE user_info.userNo = newsarticle.editorNo order by newsarticle.submissionDate DESC');
					$arr=array();
					while($row = mysqli_fetch_assoc($result)) {
						$arr[]=$row;
					}
					
					$jsn=json_decode(json_encode($arr),true);
					$counter=0;
					foreach($jsn as $news){
					?>
					<form action="newsInformation.php" style="margin:0px;">
					<table id="newsInfoTable" style="margin:0px;" border="0px" cellspacing="0px">
					<?php 
					if($counter==0)
						echo    '<tr><th>Action</th>
								<th>IMG</th>
								<th>First Name</th>
								<th>Last Name</th>
								<th>Upload Date</th>
								<th>Type</th>
								<th>Title</th>
								<th>Subject</th>
								<th>Content</th>
								<th>Report</th>
								<th>Deleted</th>
								</tr>';
					$counter++;
					?>
					
					<tr> 
					
						<td><button type="button" onclick="updateNews(this)" id="<?php echo $news["N_A_no"];?>" >Update</button></td>
						<td><img width="35px" height="35px" src="<?php echo $news["photo"]; ?>" alt="No Image" ></td>
						<td> <input type="text" disabled id="firstName<?php echo $news["N_A_no"];?>" value="<?php echo $news["firstName"]; ?>" name="firstName" > </td>
						<td> <input type="text" disabled id="lastName<?php echo $news["N_A_no"];?>" value="<?php echo $news["lastName"]; ?>" name="lastName" > </td>
						<td><?php echo $news["submissionDate"]; ?></td>
						
						<td>
							<select name="newsType" disabled id="newsType<?php echo $news["N_A_no"];?>">
							<option value="News" <?php if($news["type"]=="News") echo "selected"; ?> > News </option>
							<option value="Artical" <?php if($news["type"]=="Artical") echo "selected"; ?> > Artical </option>
							<option value="Job Circular" <?php if($news["type"]=="Job Circular") echo "selected"; ?> > Job Circular </option>
							</select>
							
						</td>
						
						<td> <input type="text" disabled id="title<?php echo $news["N_A_no"];?>" value="<?php echo $news["title"]; ?>" name="title" > </td>
						<td> <input type="text" disabled id="subject<?php echo $news["N_A_no"];?>" value="<?php echo $news["subject"]; ?>" name="title" > </td>
						
						<td><div title="click to expand and again to collaps"class="contentdiv"onclick="expand(this);"><?php echo $news["content"]; ?> </div></td>
						
						<td><div title="click to expand and again to collaps"class="reportdiv"onclick="expand(this);">
						
						<?php 
						
						$report=queryDb("SELECT * from report,user_info WHERE report.reporterNo=user_info.userNo AND report.N_A_no=".$news["N_A_no"]." order by rDate desc");
						echo mysqli_num_rows($report)." Reports"."<br/>";
						echo "<ol>";
						while($reportRow=mysqli_fetch_assoc($report))
						{
							echo "<li>".$reportRow["rDate"].", ".$reportRow["firstName"]." ".$reportRow["lastName"]." reported : \" ".$reportRow["report"]." \"</li>";
						}
						echo "</ol>";
						?> </div></td>
						
						
					<!--	<td> <input type="text" disabled id="mail<?php echo $news["N_A_no"];?>" value="<?php echo $news["mail"]; ?>" name="mail" > </td>
					  -->	
						<td>
						<select name="deleted" id="deleted<?php echo $news["N_A_no"];?>">
							<option value="1" <?php if($news["deleted"]==1) echo "selected"; ?> > YES </option>
							<option value="0" <?php if($news["deleted"]!=1) echo "selected"; ?> > NO </option>
						</select>
						
						</td>
						
						
					
					</tr>
					</table>
					</form>	
				<?php	}
				?>
            
					

</body>
</html>
