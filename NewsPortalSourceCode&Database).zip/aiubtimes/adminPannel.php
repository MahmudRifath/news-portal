<?php

		session_start();
		if(isset($_SESSION['user']) && isset($_SESSION["admin"]))
		{	
			if(!$_SESSION['user']=='valid' && !$_SESSION["admin"] ){
				header("location:signin.php");
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{
			header("location:signin.php");
		}
		?>
<?php include("header.php");?>
<html>
<head>
    <style>
        #adminContainer {
			width:97%;
			margin-top:50px;
			margin-left:10px;
		}
        
        #sideMenue {
            width: 10%;
        }
        .menueButton{
			cursor:pointer;
           color: rgb(235, 223, 223); 
		   text-align: center;
		   margin-left: 5px;
		   margin-top: 10px;
		   margin-right:10px;
		   width: 200px;
		   height: 42px;
		   background: linear-gradient(0deg, rgb(237, 7, 21) 62%, rgb(224, 123, 123) 100%);
        }
		#rightSidePage{
			padding-top:20px;
			padding-bottom:20px;
			padding-left:10px;
			overflow:auto;
			width:1080px;
			max-height:420px;
			margin:0px;
			background:#e4e4e4eb;
		}
		#rightSide{
			//width:10%;
		}
		#rightSidePageTitle{
			font-weight:bold;
			z-index:2;
			margin:8px 0 3px
		}
    </style>
	<script> 
		function getPage(url){
				var  xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {			
				var m=document.getElementById("rightSidePage");
				m.innerHTML=xmlhttp.responseText;
				}
				};
				xmlhttp.open("GET", url,true);
				xmlhttp.send();
		}
		function updateNews(news){
				news=news.id;
				getPage("newsInformation.php?news="+news+"&deleted="+document.getElementById("deleted"+news).value);
				document.getElementById("updateNotification").innerHTML=" <img src='icon/tick.png' alt=''> 1 Row updated !";
				setInterval(function(){document.getElementById("updateNotification").innerHTML="";},4000);
		
		}
		function updateUser(userno){
				userno=userno.id;
				var  xmlhttp = new XMLHttpRequest();
				
				var firstName=document.getElementById("firstName"+userno).value;
				var lastName=document.getElementById("lastName"+userno).value;
				var userType=document.getElementById("userType"+userno).value;
				var gender=document.getElementById("gender"+userno).value;
				var mail=document.getElementById("mail"+userno).value;
				var contact=document.getElementById("contact"+userno).value;
				var validation=document.getElementById("validation"+userno).value;
				
				
				if( 
					firstName.length==0 ||
					lastName.length ==0 ||
					mail.length==0		||
					!parseInt(contact)	||
					contact.length<10	||
					!/\S/.test(firstName)||
					!/\S/.test(lastName) ||
					!/\S/.test(mail)		||
					!/\S/.test(contact)	
				){
					document.getElementById("updateNotification").innerHTML=" <img src='icon/warning.png' alt=''> Provide valid data !";
					setInterval(function(){document.getElementById("updateNotification").innerHTML="";},4000)
				}
				else{
					if(confirm("Are you sure to update the user ? ")){
							xmlhttp.onreadystatechange = function() {
							if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {			
								getPage("userinfo.php");
								document.getElementById("updateNotification").innerHTML=" <img src='icon/tick.png' alt=''> 1 Row updated !";
								setInterval(function(){document.getElementById("updateNotification").innerHTML="";},4000);
							}
							};
							var url="updateUser.php?firstName="+firstName+"&lastName="+lastName+"&userType="+userType+"&gender="+gender+"&mail="+mail+"&contact="+contact+"&validation="+validation+"&userNo="+userno;
							xmlhttp.open("POST", url,true);
							xmlhttp.send();
						}
			}
		}
		
		function rightSidePageTitle(title){
			document.getElementById("rightSidePageTitle").innerHTML=title;
		}
		
		function expand(div){
			if(div.style.width<"200px"){
			div.style.width="400px";
			div.style.height="auto";
			div.style.overflow="auto"}
			else
				{
			div.style.width="100px";
			div.style.height="30px";
			div.style.overflow="hidden"}
		}
	</script>
</head>

<body>
    <table id="adminContainer"  border="0px">
        <tbody>
            <tr>
					<!-- LEFT SIDE MENUE -->
					<td valign="top" width="15%">
						<table id="sideMenue" >
							<tbody>
								<tr>
										
										<td >
											<button class="menueButton" onclick="getPage('userinfo.php');rightSidePageTitle('USER INFORMATION');"> User Information </button>
										</td>
									
								</tr>
								<tr>
								
										<td>
											<button class="menueButton" onclick="getPage('newsInformation.php');rightSidePageTitle('NEWS INFORMATION');"> News Information </button> 	
										</td>
							
								</tr>
								<tr>
								
										<td>
											<button class="menueButton" onclick="getPage('feedBackInformation.php');rightSidePageTitle('Feedback INFORMATION');"> Feedback Information </button> 	
										</td>
							
								</tr>
	
							</tbody>
						</table>
					</td>

					
					
				<!-- RIGHT SIDE PAGE -->	
				<td id="rightSide">
					<p id="rightSidePageTitle" align="center"></p>
					<span id="updateNotification" color="green"></span>
					<div id="rightSidePage" >
					<div>
                </td>
            </tr>
        </tbody>
    </table>
<script>getPage('userinfo.php');rightSidePageTitle('USER INFORMATION');</script>
</body>
</html>