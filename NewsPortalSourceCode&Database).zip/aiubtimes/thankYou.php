<script>
function closew(){
	close();
}
</script>

<?php

	
echo	'<h1 style="text-align: center;">&nbsp;</h1>
<h1 style="text-align: center;">&nbsp;</h1>
<h1 style="text-align: center;">&nbsp;</h1>
<h1 style="text-align: center;">&nbsp;</h1>
<h1 style="text-align: center;"><span style="color: #999999;">THANK YOU FOR LETTING US KNOW</span></h1>
<h3 style="text-align: center; cursor: pointer;" onclick="closew()"><strong><span style="color: #999999;">CLOSE</span></strong></h3>
<p>&nbsp;</p>'
	
?>