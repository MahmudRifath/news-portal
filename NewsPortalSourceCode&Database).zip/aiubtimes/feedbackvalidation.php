<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Feed Back Validation</title>
</head>
<body>
    
    <?php
    
      $con=mysqli_connect("localhost","root","","aiub_times");
					
					if(!$con){
						die("Connection error");
					}  
        
    if( isset($_REQUEST["name"]) && isset($_REQUEST["mail"]) && 
        isset($_REQUEST["newstype"]) && isset($_REQUEST["gender"]) &&
        isset($_REQUEST["ratingw"]) && isset($_REQUEST["ratings"]) &&
        isset($_REQUEST["comment"]) ) {
            
            if(filter_var($_REQUEST["mail"], FILTER_VALIDATE_EMAIL)){


                //echo $_REQUEST["name"]."<br/>";
                //echo $_REQUEST["mail"]."<br/>";
                //echo $_REQUEST["gender"]."<br/>";
                //echo $_REQUEST["newstype"]."<br/>";
                //echo $_REQUEST["ratingw"]."<br/>";
                //echo $_REQUEST["ratings"]."<br/>";
                //echo nl2br(htmlspecialchars($_REQUEST["comment"]))."<br/>";
            
			
			/*$con=mysqli_connect("localhost","root","","aiub_times");
					
					if(!$con){
						die("Connection error");
					}*/
					
					$sql="INSERT INTO `feedback`(`name`, `newsType`, `Email`, `gender`, `ratingWebsite`, `ratingSupport`, `comment`)
							VALUES ('".$_REQUEST["name"]."','".$_REQUEST["newstype"]."','".$_REQUEST["mail"]."','".$_REQUEST["gender"]."','".$_REQUEST["ratingw"]."','".$_REQUEST["ratings"]."','".$_REQUEST["comment"]."')";
					
					//echo $sql;
					if(mysqli_query($con,$sql)){
						header("location:thankYou.php");
					}
					else{ header("location:feedback.html");}
            }
			else
            {
                echo "Please Provide a VAlID EMAIL.";
            }

        }
        else{
         echo "ALL information must be given to continue.";   
        }
        
        
    ?>
    
</body>
</html>