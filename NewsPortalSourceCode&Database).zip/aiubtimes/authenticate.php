<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Authenticate</title>
</head>
<body>
    
    <?php
    
	//$file=fopen("userfile.txt","r") or die("File NOT Found");
	if(isset($_REQUEST["uname"]) && $_REQUEST["pass"]){
	$uname=$_REQUEST["uname"];
	$pass=md5($_REQUEST["pass"]);
	//$pass=$_REQUEST["pass"];
	}
	else
	{
		header("location:signin.php");
		exit;
	}
	$flag=0;
    
	
	if(isset($_REQUEST["uname"]) && isset($_REQUEST["pass"])){
    	
					$con=mysqli_connect("localhost","root","","aiub_times");
					
					if(!$con){
						die("Connection error");
					}		
					//hashing password
					//$password=md5($password);
					//query
					$sql="SELECT * from `user_info` WHERE mail='$uname' and password='$pass' and validation='valid'";
					
					echo $sql;
					if($result=mysqli_query($con,$sql)){
								
								if(mysqli_num_rows($result)==1){
									$row=mysqli_fetch_assoc($result);
									session_start();
									
									unset($_SESSION["user"]);
									unset($_SESSION["uname"]);
									unset($_SESSION["usertype"]);
									unset($_SESSION["userNo"]);
									unset($_SESSION["photo"]);
									unset($_SESSION["admin"]);
									
									
									$_SESSION["user"]="valid";
									
									if($row['usertype']=="admin"){
										$_SESSION["admin"]=true;
									}
									
									
									$_SESSION["uname"]=$row['mail'];
									$_SESSION["usertype"]=$row['usertype'];
									$_SESSION["userNo"]=$row["userNo"];
									$_SESSION["photo"]=$row["photo"];
									header("Location:home.php");
								}
								else header("Location:signin.php?q=error&u=".$uname);
					}
	}
    ?>
    
</body>
</html>