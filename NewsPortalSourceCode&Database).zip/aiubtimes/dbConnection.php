<?php

  function queryDb( $sql ){
  $result=null;
  $con =mysqli_connect("localhost","root","","aiub_times");
  
  if(!$con){
    die();
  }
  else{
    if($result=mysqli_query($con,$sql));
	return $result;
	return null;
  }
  return null;
  
  }
?>
