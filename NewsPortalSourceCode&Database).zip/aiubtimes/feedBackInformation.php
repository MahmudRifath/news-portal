<?php

		session_start();
		if(isset($_SESSION['user']) && isset($_SESSION["admin"]))
		{	
			if(!$_SESSION['user']=='valid' && !$_SESSION["admin"] ){
				header("location:signin.php");
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{
			header("location:signin.php");
		}
?>

<ol>
<?php
	
	include("dbConnection.php");
	$result=queryDb('SELECT CONCAT(`name`," ", `newsType`," ", `Email`," ", `gender`," ", `ratingWebsite`," ", `ratingSupport`," ", `comment`) as feed FROM `feedback`');
	
	while($row=mysqli_fetch_assoc($result))
	{
		echo "<li>".$row["feed"]."</li>";
	}

?>
</ol>