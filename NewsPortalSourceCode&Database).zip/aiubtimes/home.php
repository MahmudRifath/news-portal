<?php
		session_start();
		if(isset($_SESSION['user']))
		{	
			if(!$_SESSION['user']=='valid'){}
		}
		
		$tag="";
		if(!isset($_GET['tag'])){
			$tag="home";
		}
		else
		{
			$tag=$_GET['tag'];
		}
		?>

<head>
    <meta charset="utf-8">
    <title>AIUB TIMEs</title>
	<link rel="stylesheet" href="css/homePageStyle.css">
	<style type="text/css">
	#newComment{
	<?php if(isset($_SESSION['user']))
	{	
	if($_SESSION['user']=='valid'){
	echo '
	margin-left:10px;
	margin-right:10px; 
	height:30px;
	width:310px;
	border:1px solid gray;
	padding:5px;
	outline:transparent;
	border-radius:10px;';
	}
	}
	else echo 'display:none;';
	?>
	}
	
	#newCommentBtn{
	<?php if(isset($_SESSION['user']))
	{	
	if($_SESSION['user']=='valid'){
	echo '
	margin-top:10px;
	height:30px;
	border-radius:5px;
	cursor:pointer;';
	}
	}
	else echo 'display:none;';
	?>
	}
	
    </style>
	
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
	
	<script>
	
var gloabalNews;
	
	function searchResult() {
		var  xmlhttp = new XMLHttpRequest();
		var str=document.getElementById('searchTerm').value;
		xmlhttp.onreadystatechange = function() {
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200 ) {			
				var m=document.getElementById("leftspace");
				m.innerHTML=xmlhttp.responseText;
				if(xmlhttp.responseText.length<50){
					m.innerHTML="<p style='font-size:1.3em;color:rgb(155,0,0);'>No Result Found ! </p>"+
								"<p style='font-size:1.3em;color:rgb(155,0,0);'>try using different search term </p>";
				}
			}
		};
		var url="searchNews.php?titleSearch="+str+"&searchTag="+"<?php echo $tag;?>";
		xmlhttp.open("GET", url,true);
		xmlhttp.send();
	}

	function like(newslike){
						
		var  xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {

		if (xmlhttp.readyState == 4 && xmlhttp.status == 200 ) {
				newslike.innerHTML=xmlhttp.responseText;
				
			}
		};
		var url="like.php?news="+newslike.id;
		//alert(url);
		xmlhttp.open("GET", url,true);
		xmlhttp.send();
		
		var  xmlhttp1 = new XMLHttpRequest();
		xmlhttp1.onreadystatechange = function() {

		if (xmlhttp1.readyState == 4 && xmlhttp1.status == 200 ) {
				var elms = document.querySelectorAll("[id='likeSpan"+newslike.id+"']");
				for(var i = 0; i < elms.length; i++) 
				{ elms[i].innerHTML=xmlhttp1.responseText;
					
				}		
			}
		};
		var url="likeNumberUpdate.php?news="+newslike.id;
		xmlhttp1.open("GET", url,true);
		xmlhttp1.send();
	}

	function isLiked(newslike,newsno){
		var  xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {

		if (xmlhttp.readyState == 4 && xmlhttp.status == 200 ) {
				document.getElementById(newslike).innerHTML=xmlhttp.responseText;
			}
		};
		var url="isLiked.php?news="+newsno;
		xmlhttp.open("GET", url,true);
		xmlhttp.send();
	}
							
	function getComments(comment){
		var  xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {

		if (xmlhttp.readyState == 4 && xmlhttp.status == 200 ) {
				document.getElementById("allcomment").innerHTML= xmlhttp.responseText;
			}
		};
		var url="commentNews.php?news="+comment;
		xmlhttp.open("GET", url,true);
		xmlhttp.send();
	}
	
	//Comments 
	function sendComment(){
		var commentText=document.getElementById("newComment").value;
		
		if(commentText.length>0 && /\S/.test(commentText) ){
			var  xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {

			if (xmlhttp.readyState == 4 && xmlhttp.status == 200 ) {
					getComments(gloabalNews);
					document.getElementById("newComment").value="";
				}
			};
			var url="sendCommentNews.php?news="+gloabalNews+"&comment="+commentText;
			xmlhttp.open("GET", url,true);
			xmlhttp.send();
		}
		else{alert("write a comment");}
	}
	
	function deleteComment(cNo){
	
		var  xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {

		if (xmlhttp.readyState == 4 && xmlhttp.status == 200 ) {
				getComments(gloabalNews);
			}
		};
		var url="deleteComment.php?news="+gloabalNews+"&cNo="+cNo;
		//alert(url);
		xmlhttp.open("GET", url,true);
		xmlhttp.send();
	
	}
	//slideShow
    var slides=7;
	$(function () {
        var i = Math.floor(Math.random() * 3);
        $("#rightspace").css("background-image", "url(slideShow/" + i + ".jpg)");
        setInterval(function () {
            i++;
            if (i == slides) {
                i = 0;
            }
            $("#rightspace").fadeOut("slow", function () {
                $(this).css("background-image", "url(slideShow/" + i+ ".jpg)");
                $(this).fadeIn("slow");
            });
        }, 6000);
    });
	
	var printFile="";
	function printNews() {
		var printWindow = window.open('', '', 'height=650,width=900');
		printWindow.document.write(printFile);
		printWindow.document.close();
		printWindow.print();
	}
	</script>
</head>

<?php include("header.php");?>

<body style="width:100%">
<div id="midcontainer">

	<div id="myModal" class="modal">

	  <!-- Modal content -->
	  <div class="modal-content">
		<span class="close">&times;</span>
		<p id="popNews">Some text in the Modal..</p>
	  </div>

	</div>
			
	<div class="fixedwidth">
	
		<table width="100%" border="0px" id="midtable">
			
			<?php
			//data extract
			$con = mysqli_connect('localhost','root','');
			mysqli_select_db($con, 'aiub_times');
			include("dbConnection.php");
			
			
			echo '
			<script>
				document.getElementById("'.$tag.'").className="tselected";
			</script>
			';
			
			$results_per_page = 6;
			
			$sql='SELECT * FROM `newsarticle` where  `deleted`!=1 and  tags like "%'.$tag.'%"';
			$result = mysqli_query($con, $sql);
			$number_of_results = mysqli_num_rows($result);
			$number_of_pages = ceil($number_of_results/$results_per_page);
			
			if (!isset($_GET['page'])) {
			  $page = 1;
			} else {
			  $page = $_GET['page'];
			}
			
			$this_page_first_result = ($page-1)*$results_per_page;
			
				
			$sql='SELECT * FROM `newsarticle`,`user_info` WHERE `newsarticle`.`editorNo`=`user_info`.`userNo` and `deleted`!=1 
				and tags like "%'.$tag.'%" ORDER BY `submissionDate` DESC LIMIT ' . $this_page_first_result . ',' .  $results_per_page;
			
			$result = mysqli_query($con, $sql);
			?>

		
		<tr>
		<td style="padding-top: 0px; height:516px;" valign="top"  width="90%">
		<div id="leftspace">
		
		<?php
			while($row=mysqli_fetch_assoc($result))
			{
				$likes=mysqli_fetch_assoc(queryDb('SELECT count(*) as likes FROM `likesdislikesna` WHERE N_A_no='.$row["N_A_no"]));
				//$likes=$likes["likes"];
				
				
				echo'<div  id="newspart" title="Click To Read" onclick="show(this,\''.ucfirst($row['title']).'\')" class="'.$row["N_A_no"].'">';
				
				echo '<div><b> <p id="newstitle">';
				echo "<span id='likeSpan".$row["N_A_no"]."' class='Likes'>" .
				'<img id="likesCount" src="icon/likeNo.png">'.$likes["likes"]. "</span>".
				'<span>'.$row['title']."</span>";
				echo '</p></b></div> <div id="newscontent">';
				$date=explode(" ",$row["submissionDate"]);
				echo '<div style=" border-radius:3px; padding-top:2px; width:98%;">'.$row['subject']."<cite id='authercite'>, ".$row["firstName"]." ".$row["lastName"]." ".date_format(date_create($date[0]),"M, d")."</cite> </div>" ;
				
				echo $row['content'];
				
				echo '</div></div>';
				//echo '<div id="bground" class ="blur"></div>';
			}
				
			
			?>
		</div>
			
		</td>
		
		<!-- <td width="25%" valign="top">
		
			<div style="border-radius:10px;" id="rightspace">
				
			</div>
			<br/><br/>
			
			<iframe style="border-radius:10px;" width="98%" height="300px" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d9706.630812273579!2d90.42148920399113!3d23.821918517839435!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c648a7768e31%3A0xebb579b6a6bc3c67!2sAIUB+Permanent+Campus!5e0!3m2!1sbn!2sbd!4v1513970967757" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
			
		</td> -->
		</tr>
		<tr> 
		<td>
			<?php
			// pages
			echo '<div style="margin-top:-15px;" align="center">';
			for ($page=1;$page<=$number_of_pages;$page++) {
			  echo '<a style="text-decoration:none;" href="home.php?tag='.$tag.'&page=' . $page . '">'.'<li style="list-style:none;display:inline-block;" class="pageNumber"  id="page'.$page.'" >' . $page . '</li></a> ';
			}
			echo '</div>' ?>
		</td>
		</tr>	
		</table>

	</div>

</div>

	
<div id="reportPop" class="modalReport">

			  <!-- Modal content -->
			  <div class="modal-content-report">
				<span class="closeReport">&times;</span>
				<p id="popNews">Tell Us Why ?</p>
				<textarea maxlength="200" id="reportText"></textarea>
				<button type="button" id="reportbtn"  onclick="sendReport()">Report</button>
			  </div>

			</div>
<script>
<?php 
			$p=1;
			if(isset($_GET['page'])){
			$p = $_GET['page'];
			}
			echo 'document.getElementById("page'.$p.'").className="pselected";'
?>
var modal = document.getElementById('myModal');
var span = document.getElementsByClassName("close")[0];

var modalReport = document.getElementById('reportPop');
var reportbtn = document.getElementById('reportbtn');
var spanReport = document.getElementsByClassName("closeReport")[0];

span.onclick = function() {
    modal.style.display = "none";
}
modal.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}


spanReport.onclick = function() {
    modalReport.style.display = "none";
	
}


window.onclick = function(event) {
    if (event.target == modalReport) {
        modalReport.style.display = "none";
    }
}



//NEWS POP UP Handel 
function show(news,title){
	modal.style.display = "block";

	gloabalNews=parseInt(news.className);
	var btnid=parseInt(news.className);
	
	printFile="<br/>"+title+"<br/>"+news.childNodes[2].innerHTML;
	
	document.getElementById("popNews").innerHTML="<br> <div style='text-align:justify'>"+news.childNodes[0].innerHTML+news.childNodes[2].innerHTML+"</div><br/>"
													+'<div  id="newCommentBtn" style="margin-left:auto; margin-right:0px; width:180px;" >'
													+' <button type="button" id="newCommentBtn" style="width:150px;" onclick="printNews()">Download</button> <img src="icon/flag.png" title="Want to Report This ?" onclick="reportNews('+gloabalNews+')"></div><br/><br/>'
													+"<hr/>"
													+'<table><tr><td valign="top"><button style="margin-top:10px; background:transparent;" id="'+parseInt(news.className)
													+'" onclick="like(this)" ><img src="icon/like.png"></button></td><td valign="bottom">'
													+'<input type="text"  id="newComment" placeholder="wrirte comment" onkeydown = "if (event.keyCode == 13) sendComment()" /></td><td valign="middle">'
													+'<button type="button" id="newCommentBtn" onclick="sendComment()">Comment</button></td>'
													+'<td></td></tr></table><br/>'
													+'<div id="allcomment"></div>';
	var btnid=parseInt(news.className);
	isLiked(btnid,parseInt(news.className));
	getComments(btnid);
}

//popUp confermation Report
function reportNews(news){
		//prompt("Tell Us Why?");
		var clearReport=document.getElementById('reportText');
		
		clearReport.style.border="1px solid black";
		
		modalReport.style.display="block";
		
}

//sending Report
function sendReport(){
	var r=document.getElementById('reportText');
	if(r.value.length>0){
						modalReport.style.display="none";
						var  xmlhttp = new XMLHttpRequest();
						xmlhttp.onreadystatechange = function() {

						if (xmlhttp.readyState == 4 && xmlhttp.status == 200 ) {
								
							}
						};
						var url="sendReport.php?news="+gloabalNews+"&report="+r.value;
						//alert(url);
						xmlhttp.open("GET", url,true);
						xmlhttp.send();
						document.getElementById('reportText').value="";
	}
	else{
		r.style.border="2px solid red";
	}
}


elms=document.querySelectorAll("[id='newspart']");
var rx=/("\/aiubtimes\/kcfinder[^"]*")/;
for(var k = 0; k < elms.length; k++){ 
  
		var m = rx.exec(elms[k].innerHTML)
console.log(elms[k].innerHTML+"\n\n");
	if( m!= null)
	{
	elms[k].style.background= 'url('+m[0]+')';
	elms[k].style.backgroundSize = "100% 100%";
	//belms[i].style.opacity = "0.1";
	
//		console.log(m[0]+"\n\n");
	}
	
}

</script>

<?php include("footer.php");?>