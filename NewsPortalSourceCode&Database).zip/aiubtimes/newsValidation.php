<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>News Validation</title>
</head>
<body>
    
    <?php
	
		session_start();
		if(isset($_SESSION['user']))
		{	
			if(!$_SESSION['user']=='valid'){
				header("location:signin.php");
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{
			header("location:signin.php");
		}
	
	
	
	//print_r($GLOBALS);
	//$path="";
	/*if(isset($_FILES['upload']['tmp_name']))
	{
		echo "in if upload";
	$pic=$_FILES['upload']['tmp_name'];
	$path="news/".$_FILES['upload']['name'];
	move_uploaded_file($pic,$path);
	//header("Location:postNews.html");
	}
	*/
    
    $conn=mysqli_connect("localhost","root","","aiub_times");
	if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
    }
	
	if(isset($_REQUEST["type"]) && isset($_REQUEST["title"]) && isset($_REQUEST["subject"]) && isset($_REQUEST["newstext"]))
    {
		if(strlen($_REQUEST["type"])>1 && strlen($_REQUEST["title"])>1 &&strlen($_REQUEST["subject"])>1 && strlen($_REQUEST["newstext"])>1 )
		{
			$tags="@home";
			foreach($_REQUEST["tags"] as $tag){
				$tags.="@".$tag;
			}
			
			
		$sql="INSERT INTO `newsarticle`(`type`, `title`, `subject`, `content`,`submissionDate`,`editorNo`,`tags`) VALUES ('".$_REQUEST["type"]."','".$_REQUEST["title"]."','".$_REQUEST["subject"]."','".$_REQUEST["newstext"]."',NOW(),$id,'$tags') ";
		echo $sql;
		if(mysqli_query($conn,$sql)){
			echo "New records inserted successfully";
			header("location:home.php");
		}
		else{
			echo "faild to post news";
		//echo $sql;
		}
		}
		else{
			echo "please fill up all information";
		}
	}
    
    
    ?>
    
    
</body>
</html>