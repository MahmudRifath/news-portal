<html>
 <head>
 <link rel="stylesheet" href="css/headerStyle.css">
 <script>
 <?php if(isset($_SESSION["user"])){
	
   echo 'function isLoggedIn(){
		alert("Sign Out Before Proceding");
		return false;
   }
	'; 
}
 
 if(isset($_SESSION["user"]) ){
	 if($_SESSION["usertype"]=="visitor"){
	
   echo 'function isVisitor(){
		alert("Only Editors are allowed to post news.");
		return false;
   }
	';
	 }
}
 ?>
 </script>

</head>
<body>
    <div id="container">
        <div id="topbar">	
		    <div class="fixedwidth">
			
				<a href="home.php" style="text-decoration:none;">
                <div id="logo">
                    <big><b>AIUB</b></big>
                </div>
				</a>
				
				<?php 	
					//session_start();
					if(isset($_SESSION["user"])){
					echo '<div id="signin">';
					echo '<a href="profile.php"  title="PROFILE"><img src="'.$_SESSION["photo"].'" alt="user"></a>';
					echo '<a href="signout.php" style="color:rgb(150,0,0); font-size:1.2em;"><span style="margin-top:0px;"><div id="signinbtn"> Sign Out';
					echo '</div></a></div>';
					}
					else
					{
					echo '<div id="signin">';
					echo '<a href="profile.php" title="PROFILE"><img src="icon/user.png" alt="user" ></a>';		
					echo '<a href="signin.php" style="color:white; font-size:1.2em;"><span style="margin-top:0px;"><div id="signinbtn"> Sign In';
					echo '</div></a></div>';
					}
				
				?>

                <div id="menu">
                    <ul>
					<a href="postNews.php" onclick="return isVisitor()" style="color:white"><li>Post News</li></a>
					
					<a href="feedBack.html" target="_blank" style="color:white"><li>Opinion</li></a>
					<a href="editorsSignUp.php" onclick="return isLoggedIn();" style="color:white"><li>Sign Up</li></a>
					<a href="home.php"  style="color:white"><li>News and Articals </li></a>
                    </ul>
                </div>

                <div id="search">
                    <input type="text" onkeyup="searchResult();" name="search" id="searchTerm" style="background-image: url('icon/search.png'); background-position: 100% 50%;background-repeat: no-repeat;" placeholder="search here by Title" value="">
                </div>
            </div>

            <div class="break">
            </div>

            <div id="newsbar">
                <div class="fixedwidth">

				<a href="demo.php" style="color:white;"><p id="newsheader" >AIUB<sub><i>Times</i></sub> </p></a>
					<?php 
					if(isset($_SESSION["admin"]))
					echo '<a href="adminPannel.php" " > <button  class="AdminButton" > Admin Panel </button></a>'; ?>
	
				<div class="break">
				</div>

				<div id="topic">
					<ul>
					<a href="home.php?tag=home" id="midbaroption"><li id="home">Home</li></a>
					<a href="home.php?tag=technology" id="midbaroption"><li id="technology">Technology</li></a>
					<a href="home.php?tag=sports" id="midbaroption"><li id="sports">Sports</li></a>
					<a href="home.php?tag=weather"  id="midbaroption"><li id="weather">Weather</li></a>
					<a href="home.php?tag=accident" id="midbaroption"><li id="accident">Accidents</li></a>
					<a href="home.php?tag=literature" id="midbaroption"><li id="literature">Literature</li></a>
					<a href="home.php?tag=others" id="midbaroption"><li id="others" style="border-right:0px;">Others</li></a>
					</ul>

				</div>
                </div>

            </div>
        </div>

        <div class="break">
        </div>
	</div>
</body>
</html>
