<!DOCTYPE html>
<html>

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<meta name="keywords" content="footer, address, phone, icons" />

	<title>Footer With Address And Phones</title>

 <!--	<link rel="stylesheet" href="css/demo.css"> -->
	<link rel="stylesheet" href="css/footer-distributed-with-address-and-phones.css">
	
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Cookie" rel="stylesheet" type="text/css">

</head>

	<body class="fixedwidth">

		<footer class="footer-distributed">

			<div class="footer-left">

				<h3>AIUB Times<span><img width="50px" height="50px" src="icon/aiub.png" alt="aiublogo"></span></h3>

				<p class="footer-links">
					<a href="home.php?tag=home">Home</a>
					·
					<a href="feedback.html">Opinion</a>
					·
					<a href="#">Contact</a>
				</p>

				<p class="footer-company-name">AIUB Times Founded in 2019</p>
			</div>

			<div class="footer-center">

				<div>
					<i class="fa fa-map-marker"></i>
					<p><span><a target="_blank" href="https://www.google.com/maps/dir/''/aiub/@23.7946799,90.3324597,12z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3755c711d13bbec7:0xc47f7c3e8e2263f2!2m2!1d90.4025001!2d23.7946957">
					408/1, Kuratoli, Khilkhet</a> </span> Dhaka 1229, Bangladesh</p>

				</div>

				<div>
					<i class="fa fa-phone"></i>
					<p>+88 01617449246</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p>mahmudrifath345@gmail.com</p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>About the Site</span>
					Get latest News, Articals, Job Information and a lot more.
				</p>

				<div class="footer-icons">

					<a href="#"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
					<a href="#"><i class="fa fa-linkedin"></i></a>
					
				</div>

			</div>

		</footer>

	</body>

</html>
