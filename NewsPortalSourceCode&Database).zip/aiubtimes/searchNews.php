<?php								include("dbConnection.php");
									$con = mysqli_connect('localhost','root','');
									mysqli_select_db($con, 'aiub_times');
									
									$results_per_page = 2;
									$sql="select * from newsarticle";
							
									$titleSearch="";
									if(isset($_GET["titleSearch"])){
										if($_GET["titleSearch"]!=""){
								
										$titleSearch=$_GET["titleSearch"];
										$sql='SELECT `N_A_no`, `type`, LOWER(`title`) as title , `subject`, `content`, `image`, `submissionDate`, `editorNo`, `likes`, `dislikes` ,`user_info`.* FROM `newsarticle`,`user_info` where `newsarticle`.`editorNo`=`user_info`.`userNo` and deleted!=1 and title like "%'.strtolower($titleSearch).'%"   and tags like "%'.$_GET["searchTag"].'%"';// LIMIT ' . $this_page_first_result . ',' .  $results_per_page;
										//echo $sql;
										}
										else
										{
											$sql='SELECT `N_A_no`, `type`, LOWER(`title`) as title , `subject`, `content`, `image`, `submissionDate`, `editorNo`, `likes`, `dislikes` ,`user_info`.* FROM `newsarticle`,`user_info` where `newsarticle`.`editorNo`=`user_info`.`userNo` and deleted!=1 and  tags like "%'.$_GET["searchTag"].'%" order by submissionDate desc LIMIT 0,5';// LIMIT ' . $this_page_first_result . ',' .  $results_per_page;
											//echo $sql;
										}
									}
									else
									$sql='SELECT * FROM `newsarticle` ';
								
									$result = mysqli_query($con, $sql);
									
								
									
									
									
									while($row=mysqli_fetch_assoc($result))
										{
											$likes=mysqli_fetch_assoc(queryDb('SELECT count(*) as likes FROM `likesdislikesna` WHERE N_A_no='.$row["N_A_no"]));
													
													echo'<div id="newspart" title="Click To Read" onclick="show(this,\''.ucfirst($row['title']).'\')"  class="'.$row["N_A_no"].'">';
													echo '<b> <p id="newstitle">';
													echo "<span id='likeSpan".$row["N_A_no"]."' class='Likes'>" .'<img id="likesCount" src="icon/likeNo.png">'.$likes["likes"]. "</span>".ucfirst($row['title']);
													
													echo '</p></b>
												<span id="newscontent">';
												$date=explode(" ",$row["submissionDate"]);
													echo $row['subject']."<cite id='authercite'> Published by ".$row["firstName"]." ".$row["lastName"]." on ".$date[0]."</cite>".",<br/>";
													echo $row['content'];
												
										   echo '</span></div>';
										}
										
									// pages
									echo '<div style="" align="center">';
									/*for ($page=1;$page<=$number_of_pages;$page++) {
									  echo '<a href="home.php?page=' . $page . '" style="margin:1px 2px 1px 2px ;font-size:1.2em;">' . $page . '</a> ';
									}*/
									echo '</div>'
									?>