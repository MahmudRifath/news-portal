<?php

		session_start();
		if(isset($_SESSION['user']))
		{	//echo '<script>alert("'.$_SESSION['usertype'].'");</script>';
			if($_SESSION['usertype']=='visitor'){
				header("location:home.php");
			}
			
			if(!$_SESSION['user']=='valid' ){
				header("location:signin.php");
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{
			header("location:signin.php");
		}
?>

<?php include("header.php");?>
<head>
    <title>Post NEWS</title>
	<script src="ckeditor/ckeditor.js"></script>
	
    <style>
        #containerP {
            border: 1.5px solid transparent;
            padding: 5px 15px 5px;
            border-radius: 5px;
            margin: 3% auto 150px auto;
            width: 50%;
            height: auto;
            box-shadow: rgb(125, 125, 120) 2px 1px 1px 5px;
        }
    
        .news_title {
            width: 100%;
            font-size: 1em;
            font-weight: bold;
			color: white;
            height: 30px;
            margin-left: 0px;
            padding-left: 5px;
            border-radius: 10px;
            border: 1px dotted gray;
            margin-top: 7px;
            box-shadow: gray 2px 1px 1px 1px;
            outline-color: transparent;
			background-color: transparent;
        }
        
        #newstext {
            width: 100%;
            padding: 5px;
			color: white;
            border-radius: 10px;
            margin-top: 13px;
            height: 500px;
            outline-color: transparent;
            resize: none;
            white-space: pre-wrap;
            font-size: 1.2em;
			background-color: transparent;
        }
        
        #bottom_menue {
            width: 30%;
            font-size: 70%;
            height: 30px;
            margin-left: 6px;
            border-radius: 10px;
            margin-top: 2px;
            color: white;
            background-color: red;
        }
        
        #upload {
            font-size: 70%;
            margin-left: 15px;
            border-radius: 10px;
            margin-top: 2px;
            color: white;
            padding-left: 0px;
            width: 35%;
            height: 18px;
            background-color: coral;
        }
		#type{
			width: 50%;
            font-size: 1em;
            font-weight: bold;
			color: white;
            height: 30px;
            margin:0 1% 0 50%;
            padding-left: 5px;
            border-radius: 10px;
            border: 1px dotted gray;
            margin-top: 7px;
            box-shadow: gray 2px 1px 1px 1px;
            outline-color: transparent;
			background-color: transparent;
		}
		::-webkit-input-placeholder 
		{ 
		color: gray;
		}
		
		#type option{
		background-color:#737373;
		}
				
	#options option{
		//background-color:#737373;
		}
		option{
		float:left;
		}
		#options{
		margin-left:10px;
		margin-bottom:10px;
		
		float:right;
		background-color:white;
		height:37px;
		width:300px;
		overflow:auto;
		}
    </style>
	
	<script>
			var flag=false;
			function preCheck(){
				var check=true;
			flag=true;
			var error="";
			if( document.getElementById("title").value.length == 0 )
			{
				document.getElementById("title").placeholder="Title is Empty ";
				document.getElementById("title").style.background="url(icon/error.png) no-repeat right ";
				error +="Empty Title ";
				check=false;
			}
			else{document.getElementById("title").style.background="";}
			
			if( document.getElementById("subject").value.length == 0 )
			{
				document.getElementById("subject").placeholder="subject is Empty ";
				error +="Empty Subject ";
				document.getElementById("subject").style.background="url(icon/error.png) no-repeat right ";
				check=false;
			}
			else{document.getElementById("subject").style.background="";}
			
			
			if( CKEDITOR.instances.newstext.getData().length == 0 )
			{
				document.getElementById("newserror").innerHTML="empty NEWS";
				error +="Empty NEWS Content ";
				check=false;
			}
			else{document.getElementById("newserror").innerHTML="";}
			if (document.getElementById("options").selectedIndex == -1) {
			//alert("Please select TAGS for your news.");
				document.getElementById("Tag").innerHTML="No TAGS Selected:";
				error += "Empty Tags"
			check=false;
			}
			else{document.getElementById("Tag").innerHTML="TAGS:";}
			
			return check;
			}
			function check(){
			var check=preCheck();
			//alert(check);
			
			if(check==true){
			check=confirm("are you sure");
			//alert(check);
			flag=false;
			}
			
			return check;
			
			}

			
			
	</script>

</head>

<body background="images.jpg" style="background-size:cover;">

    <div id="containerP">

        <form id="postform" action="newsValidation.php" method="post" enctype="multipart/form-data" style="margin-left: 0px;">
			
            <select id="type" name="type" >
			<option  value="News">News</option>
			<option value="Article">Article</option>
			<option value="Job Circular">Job Circular</option>
			</select>
			<input id="title" class="news_title" name="title" type="text" placeholder="Title for news" onkeypress="preCheck()" />
            <br>
            <input id="subject" class="news_title" name="subject" type="text" placeholder="Subject" onkeypress="preCheck()" />
			<br/> <br/>
            <textarea id="newstext" name="newstext" placeholder="Type your news here.."  ></textarea>
			
					<script>
					
					//<![CDATA[
					CKEDITOR.replace( 'newstext',
					{
					height: '300px',
					resize_enabled : 'true'
					});
					//]]>
					</script>
			
            <div style="margin-top: 4px;">
                <input id="bottom_menue" type="submit" value="SUBMIT" onclick="return check();">
              <!--  <input type="file" id="upload" name="upload" value="Upload Image">
				-->
			 <span style="float:right ;color:white; margin-top:7px;">
			 <span id="Tag">TAGS:</span>  
			 <select id="options" title="Ctrt+ for multiple" name="tags[]" multiple onclick="preCheck()">
		
				<?php 
					include("dbConnection.php");
					
					$result=queryDb("select * from tags");
					
					while($row=mysqli_fetch_assoc($result)){
					?>
					<option value="<?php echo $row["tagName"]?>">@ <?php echo $row["tagName"]; ?></option>

				<?php	
					}
				?>
				
			</select>
			</span>
			
			</div>
			<span id="newserror" style="color:#de4a4a; margin: 50px;"></span>
        </form>

    </div>


</body>