<?php

		session_start();
		$id=-1;
		if(isset($_SESSION['user']))
		{	
			if(!$_SESSION['user']=='valid'){
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{
			exit;
		}

		include("dbConnection.php");

if(isset($_REQUEST["news"]) && $id!=-1 && isset($_REQUEST["cNo"]))
{
	if($_REQUEST["news"]>=0)
	{   $sql="UPDATE `comments` SET deleted=1 where N_A_no=".$_REQUEST["news"]." and commentNO=".$_REQUEST["cNo"];
		queryDb($sql);
		//echo $sql;
	}
}

?>