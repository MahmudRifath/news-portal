

<?php
include("dbConnection.php");
session_start();
if(isset($_FILES['myfile']['tmp_name']) && isset($_SESSION["user"])){
		
		$id=$_SESSION["userNo"];

			if($_FILES['myfile']['tmp_name']!=null){	
			//print_r($GLOBALS);
			$type=explode("/",$_FILES['myfile']['type']);
			//echo "in if";
			$img=$_FILES['myfile']['tmp_name'];
			//echo $type[0];
			if($type[0]=="image"){
				
			
			if(move_uploaded_file($img,"profile/".$id."."."jpg"))
			{
					if(queryDb("UPDATE `user_info` SET photo='"."profile/".$id."."."jpg"."' where userNo=$id")){
						$_SESSION["photo"]="profile/".$id."."."jpg";
					}
			}
			
			header("location:profile.php");
			}
			else{
			echo "Sorry its not an Image file";}
		}
}
else
{
	header("location:signin.php");
}
?>

