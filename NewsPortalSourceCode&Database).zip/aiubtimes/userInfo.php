<?php

		session_start();
		if(isset($_SESSION['user']) && isset($_SESSION["admin"]))
		{	
			if(!$_SESSION['user']=='valid' && !$_SESSION["admin"] ){
				header("location:signin.php");
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{
			header("location:signin.php");
		}
		?>
<html>
<head>
<style>
	input{
		
		width:100px;
		height:30px;
	
	}
	select{
		width:100px;
		height:30px;
	}
	#userInfoTable{
		margin:0px 0px 0px 0px; 
	}
	#userInfoTable td{
		margin-bottom:2px;
		margin-top:4px;
		text-align: center;
		padding-left:5px;
		padding-top:0px;
		//border-bottom:1px dashed black;
		background:#e4e4e4eb;
	}
	.userform{
	margin-right:0px;	
	}
	#userInfoTable th{
		background:#6e6e6e;
		color:white;
		height:40px;
		//margin-bottom:20px;
	}
</style>
</head>
<body>

				<?php
					
					include("dbConnection.php");

					$result=queryDb('SELECT * FROM 	`user_info` ');
					$arr=array();
					while($row = mysqli_fetch_assoc($result)) {
						$arr[]=$row;
					}
					
					$jsn=json_decode(json_encode($arr),true);
					$counter=0;
					foreach($jsn as $user){
					?>
					<form action="updateUserByAdmin.php" style="margin:0px;">
					<table id="userInfoTable" style="margin:0px;" border="0px" cellspacing="0px">
					<?php 
					if($counter==0)
						echo    '<tr><th>Action</th>
								<th>IMG</th>
								<th>First Name</th>
								<th>Last Name</th>
								<th>Type</th>
								<th>Gender</th>
								<th>DOB</th>
								<th>Signed Up</th>
								<th>Mail</th>
								<th>Contact</th>
								<th>Validity</th></tr>';
					$counter++;
					?>
					<tr> 
					
						<td><button type="button" onclick="updateUser(this)" id="<?php echo $user["userNo"];?>" >Update</button></td>
						<td><img width="35px" height="35px" src="<?php echo $user["photo"]; ?>" alt="No Image" ></td>
						<td> <input type="text" id="firstName<?php echo $user["userNo"];?>" value="<?php echo $user["firstName"]; ?>" name="firstName" > </td>
						<td> <input type="text" id="lastName<?php echo $user["userNo"];?>" value="<?php echo $user["lastName"]; ?>" name="lastName" > </td>
						
						<td>
							<select name="userType" id="userType<?php echo $user["userNo"];?>">
							<option value="editor" <?php if($user["usertype"]=="editor") echo "selected"; ?> > Editor </option>
							<option value="visitor" <?php if($user["usertype"]=="visitor") echo "selected"; ?> > Visitor </option>
							<option value="admin" <?php if($user["usertype"]=="admin") echo "selected"; ?> > Admin </option>
							</select>
							
						</td>
						
						<td>
						<select name="gender" id="gender<?php echo $user["userNo"];?>">
							<option value="male" <?php if($user["gender"]=="male") echo "selected"; ?> > Male </option>
							<option value="female" <?php if($user["gender"]=="female") echo "selected"; ?> > Female </option>
						</select>
						</td>

						<td><?php echo $user["DOB"]; ?></td>
						
						<td><?php echo $user["signUpDate"]; ?></td>
						<td> <input type="text" id="mail<?php echo $user["userNo"];?>" value="<?php echo $user["mail"]; ?>" name="mail" > </td>
						<td><input type="text" id="contact<?php echo $user["userNo"];?>" value="<?php echo $user["contact"]; ?>" name="contact" ></td>
						
						<td>
						<select name="validation" id="validation<?php echo $user["userNo"];?>">
							<option value="valid" <?php if($user["validation"]=="valid") echo "selected"; ?> > Valid </option>
							<option value="invalid" <?php if($user["validation"]=="invalid") echo "selected"; ?> > Invalid </option>
						</select>
						
						</td>
						
						
					
					</tr>
					</table>
					</form>	
				<?php	}
				?>
            
					

</body>
</html>
