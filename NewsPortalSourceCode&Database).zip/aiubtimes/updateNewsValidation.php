<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>News Validation</title>
</head>
<body>
    
    <?php
	
		session_start();
		if(isset($_SESSION['user']))
		{	
			if(!$_SESSION['user']=='valid'){
				header("location:signin.php");
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{
			header("location:signin.php");
		}

    
    $conn=mysqli_connect("localhost","root","","aiub_times");
	if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
    }
	
	if(isset($_REQUEST["type"]) && isset($_REQUEST["title"]) && isset($_REQUEST["subject"]) && isset($_REQUEST["newstext"]) && isset($_REQUEST["updateNewsNo"]))
    {
		if(strlen($_REQUEST["type"])>1 && strlen($_REQUEST["title"])>1 &&strlen($_REQUEST["subject"])>1 && strlen($_REQUEST["newstext"])>1 )
		{
			$tags="@home";
			foreach($_REQUEST["tags"] as $tag){
				$tags.="@".$tag;
			}
			
			
		$sql="update `newsarticle` SET `type`='".$_REQUEST["type"]."' , `title` = '".$_REQUEST["title"]."' , `subject`= '".$_REQUEST["subject"]."', `content` = '".$_REQUEST["newstext"]."' , `tags` = '$tags' where `N_A_no`=".$_REQUEST["updateNewsNo"] ;
		echo $sql;
		if(mysqli_query($conn,$sql)){
			echo "New records inserted successfully";
			header("location:home.php");
		}
		else{
			echo "faild to post news";
		//echo $sql;
		}
		}
		else{
			echo "please fill up all information";
		}
	}
    
    
    ?>
    
    
</body>
</html>