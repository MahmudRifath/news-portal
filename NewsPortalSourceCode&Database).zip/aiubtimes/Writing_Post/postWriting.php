<head>
    <title>Post Writing</title>

    <style>
        #container {
            border: 0px solid transparent;
            padding: 5px 15px 5px 30px;
            border-radius: 5px;
            margin: 4% 55.33% 10% 27%;
            width: 37.67%;
            height: 550px;
            box-shadow: rgb(125, 125, 120) 2px 1px 1px 5px;
			background-image: url(coveru.png);
			background-size:cover;
			background-repeat: no-repeat;
			
        }
        
        #news_title {
            width: 100%;
            font-size: 1.2em;
            font-weight: bold;
			color: white;
            height: 30px;
            margin-left: 0px;
            padding-left: 5px;
            border-radius: 10px;
            border: 1px dotted gray;
            margin-top: 7px;
            box-shadow: gray 2px 1px 1px 1px;
            outline-color: transparent;
			background-color: transparent;
        }
        
        #news {
            width: 100%;
            padding: 5px;
			color: white;
            border-radius: 10px;
            margin-top: 13px;
            height: 75%;
            outline-color: transparent;
            resize: none;
            white-space: pre-wrap;
            font-size: 1.4em;
			background-color: transparent;
        }
        
        #bottom_menue {
            width: 30%;
            font-size: 70%;
            height: 30px;
            margin-left: 170px;
            border-radius: 10px;
            margin-top: 2px;
            color: white;
            background-color: gray;
        }
        
        #upload {
            font-size: 70%;
            margin-left: 15px;
            border-radius: 10px;
            margin-top: 2px;
            padding-left: 0px;
            width: 35%;
            height: 18px;
            background-color: coral;
        }
		#type{
			width: 40%;
            font-size: 1em;
            font-weight: bold;
			color: white;
            height: 30px;
            margin:0 1% 0 60%;
            padding-left: 5px;
            border-radius: 10px;
            border: 1px dotted gray;
            margin-top: 7px;
            box-shadow: gray 2px 1px 1px 1px;
            outline-color: transparent;
			background-color: transparent;
		}
		::-webkit-input-placeholder 
		{ /* Chrome */
		color: white;
		}
		option{
		background-color:#737373;
		
		}
		
    </style>

</head>

<body background="writingbg.jpg"  style="background-size:cover;">

    <div id="container">

        <form id="postform" action="newsValidation.php" method="post" enctype="multipart/form-data" style="margin-left: 0px;">

            <select id="type" name="type"  required="">
			<option  value="News">News</option>
			<option value="Article">Article</option>
			<option value="Job Circular">Job Circular</option>
			</select>
			<input id="news_title" name="title" type="text" placeholder="Title for writing" required="">
            <br>
            <textarea id="news" name="newstext" placeholder="Type your writing here.." required=""></textarea>
            <div style="margin-top: 4px;">
                <input id="bottom_menue" type="submit" value="SUBMIT">
            </div>
        </form>

    </div>


</body>