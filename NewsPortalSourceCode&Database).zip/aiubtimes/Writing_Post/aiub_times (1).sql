-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2017 at 04:34 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aiub_times`
--

-- --------------------------------------------------------

--
-- Table structure for table `authentication`
--

CREATE TABLE `authentication` (
  `userNo` int(11) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `validation` varchar(50) NOT NULL,
  `userType` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `authentication`
--

INSERT INTO `authentication` (`userNo`, `mail`, `password`, `validation`, `userType`) VALUES
(1, 'atasnim92@gmail.com', 'anika111', 'valid', 'editor'),
(2, 'rifathmahmud@gmail.com', 'rifath', 'valid', 'editor');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `commentNo` int(11) NOT NULL,
  `N_A_no` int(11) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `cDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`commentNo`, `N_A_no`, `comment`, `cDate`) VALUES
(1, 2, 'dxnffgkur uefkeviugbh', '2017-11-11 05:04:00');

-- --------------------------------------------------------

--
-- Table structure for table `likesdislikesna`
--

CREATE TABLE `likesdislikesna` (
  `LDNo` int(11) NOT NULL,
  `N_A_no` int(11) NOT NULL,
  `likerNo` int(11) NOT NULL,
  `dislikerNo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `likesdislikeswriting`
--

CREATE TABLE `likesdislikeswriting` (
  `LDNo` int(11) NOT NULL,
  `WNo` int(11) NOT NULL,
  `likerNo` int(11) NOT NULL,
  `dislikerNo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `loginlog`
--

CREATE TABLE `loginlog` (
  `lNo` int(11) NOT NULL,
  `userNo` int(11) NOT NULL,
  `lDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loginlog`
--

INSERT INTO `loginlog` (`lNo`, `userNo`, `lDate`) VALUES
(1, 1, '2017-11-09 01:08:00');

-- --------------------------------------------------------

--
-- Table structure for table `newsarticle`
--

CREATE TABLE `newsarticle` (
  `N_A_no` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `content` varchar(10000) NOT NULL,
  `image` varchar(100) NOT NULL,
  `submissionDate` datetime NOT NULL,
  `editorNo` int(11) NOT NULL,
  `likes` int(11) NOT NULL,
  `dislikes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newsarticle`
--

INSERT INTO `newsarticle` (`N_A_no`, `type`, `title`, `subject`, `content`, `image`, `submissionDate`, `editorNo`, `likes`, `dislikes`) VALUES
(1, 'news', 'Road Accident', 'Accident', 'Bangladesh is a very populated country. Here road management is very bad. Every day we find road accident news in daily newspapers. I also face a road accident. Everyday go my college by local bus. Like daily activities I was going for my bus. I was standing on the rod and waiting for the bus. Then I saw two little boys are crossing the busy road. They were not enough to cross the road. When they are crossing the road a bus push them in little speed. They were very afraid for his and they also little injured. One boy\'s leg was injured and another was injured in his hand. I rushed them and treatment them. I took a medicine from the nearby dispensary and used it on the injured place. They are crying for pain. I told them where from they are and where hey want to go.', '', '2017-11-09 00:00:00', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ptspoint`
--

CREATE TABLE `ptspoint` (
  `PTNo` int(11) NOT NULL,
  `userNo` int(11) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `content` varchar(5000) NOT NULL,
  `sampleFile` varchar(50) NOT NULL,
  `domain` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `userNo` int(11) NOT NULL,
  `contact` int(11) NOT NULL,
  `DOB` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `signUpDate` date NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`userNo`, `contact`, `DOB`, `gender`, `signUpDate`, `firstName`, `lastName`) VALUES
(1, 1714339669, '1996-10-02', 'female', '2017-11-01', 'anika', 'tasnim'),
(2, 1534580001, '1996-01-16', 'male', '2017-11-04', 'rifath', 'mahmud');

-- --------------------------------------------------------

--
-- Table structure for table `writing`
--

CREATE TABLE `writing` (
  `wNo` int(11) NOT NULL,
  `userNo` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `content` varchar(3000) NOT NULL,
  `type` varchar(20) NOT NULL,
  `likes` int(11) NOT NULL,
  `dislikes` int(11) NOT NULL,
  `report` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authentication`
--
ALTER TABLE `authentication`
  ADD KEY `userNo` (`userNo`),
  ADD KEY `userNo_2` (`userNo`),
  ADD KEY `userNo_3` (`userNo`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentNo`);

--
-- Indexes for table `likesdislikesna`
--
ALTER TABLE `likesdislikesna`
  ADD PRIMARY KEY (`LDNo`);

--
-- Indexes for table `likesdislikeswriting`
--
ALTER TABLE `likesdislikeswriting`
  ADD PRIMARY KEY (`LDNo`);

--
-- Indexes for table `loginlog`
--
ALTER TABLE `loginlog`
  ADD PRIMARY KEY (`lNo`),
  ADD UNIQUE KEY `lNo` (`lNo`);

--
-- Indexes for table `newsarticle`
--
ALTER TABLE `newsarticle`
  ADD PRIMARY KEY (`N_A_no`) USING BTREE,
  ADD KEY `dislikes` (`dislikes`) USING BTREE,
  ADD KEY `likes` (`likes`) USING BTREE;

--
-- Indexes for table `ptspoint`
--
ALTER TABLE `ptspoint`
  ADD PRIMARY KEY (`PTNo`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`userNo`);

--
-- Indexes for table `writing`
--
ALTER TABLE `writing`
  ADD PRIMARY KEY (`wNo`),
  ADD UNIQUE KEY `likes` (`likes`),
  ADD UNIQUE KEY `dislikes` (`dislikes`),
  ADD UNIQUE KEY `report` (`report`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `commentNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `likesdislikesna`
--
ALTER TABLE `likesdislikesna`
  MODIFY `LDNo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `likesdislikeswriting`
--
ALTER TABLE `likesdislikeswriting`
  MODIFY `LDNo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loginlog`
--
ALTER TABLE `loginlog`
  MODIFY `lNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `newsarticle`
--
ALTER TABLE `newsarticle`
  MODIFY `N_A_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ptspoint`
--
ALTER TABLE `ptspoint`
  MODIFY `PTNo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `userNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `writing`
--
ALTER TABLE `writing`
  MODIFY `wNo` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `authentication`
--
ALTER TABLE `authentication`
  ADD CONSTRAINT `userNo_F_K_u_a` FOREIGN KEY (`userNo`) REFERENCES `user_info` (`userNo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
