 <div style="postion:absulate;z-index:10px;"><?php include("header.php");?></div>
<html>
    <head><title>SIGN in page</title>
    
    <style>
        
        #containerS{
            color:white;
            padding: 5px 5px 5px 5px;
            margin:8% 0 0 35% ;
            border: 2px solid gray;
            border-radius: 10px;
            align-content: center;
            width: 27%;
            height: auto;
            
        }
        #in_name{
            width: 80%;
            height: 6%;
            border-radius: 5px;
			padding-left:10px;
            margin-top: 40px;
        }   
        
        #in_pass{
            width: 80%;
            height:6%;
            border-radius: 5px;
            padding-left:10px;
			margin-top: 10px;
        }
        #in_sub{
			width: 80%;
			height: 6%;
			border-radius: 5px;
			margin-top: 30px;
			color: white;
			margin-bottom: 40px;
			background-color: #c43227;
	}
	#info{
		font-size:1.7em;
	}
	
	.mark{
		
		}
   </style>
    
	
	<script>
		var check=false;
		var email=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		var flag=false;
		function validate(){
			var error="";
			check=true;
			flag=true;
			if(document.getElementById("in_pass").value.length<6){
			//error+="Please Give a Valid First Name\n";
			//document.getElementById("in_pass").style.background="#f7a6a0";
			//document.getElementById("pass_mark").src = "icon/error.png";
			document.getElementById("in_pass").style.background="white url(icon/error.png) no-repeat right ";
			flag=false;
			}
			else
			{
				document.getElementById("in_pass").style.background="white ";
			//document.getElementById("pass_mark").src = "icon/checked.png";
			}
			
			if(!(email.test(document.getElementById("in_name").value))){
			error+="Please Give a Valid Email\n";
			//document.getElementById("email_mark").src = "icon/error.png";
			document.getElementById("in_name").style.background="white url(icon/error.png) no-repeat right ";
			
			flag=false;
			}
			else{document.getElementById("in_name").style.background="white url(icon/checked.png) no-repeat right ";}
			
			
			
			return flag;
		}
		
		function startCheck(){
		check=true;
		}
		setInterval(function (){if(check==true)validate();},100);
		
	 </script>
	 
	
	
    </head>
	
	
    <body style="background:url(background/signinbg.jpg); background-size:cover;">
   
        <form action="authenticate.php" method="post" >
			
            <div align="center" id="containerS" >
               <span id="info"> Sign In to Continue</span><hr>
				<?php if(isset($_REQUEST["q"]))
				{
					echo '<span ><img src="icon/warning.png"   alt=""></span><span  color="red" >Invalid username or password. </span>';		
				}
			?>
                <input id="in_name" type="text" name="uname" placeholder=" Mail" value="<?php if(isset($_REQUEST["u"])) echo $_REQUEST["u"]; ?>"  onkeypress="validate()" onchange="validate()"  /><br/>
                <input id="in_pass" type="password" name="pass" placeholder=" Password"  onkeypress="validate()"/><br/>
                <input id="in_sub" type="submit" onclick="return validate();" value="SIGN IN"/><br/>
            
            </div>
        
        
        </form>
        
    </body>
</html>