<?php
		$id=null;
		session_start();
		if(isset($_SESSION['user']))
		{	
			if(!$_SESSION['user']=='valid'){
				//header("location:signin.php");
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{
			die();
		//	header("location:signin.php");
		}
		?>
<?php 
if(isset($_REQUEST["news"])){
	include("dbConnection.php");
	$up="UPDATE `newsarticle` SET `deleted`=1 where `N_A_no`=".$_REQUEST["news"];
	queryDb($up);
}
?>
<tr> 
<th>NO.</th><th>Type</th><th>Title</th><th>Subject</th><th>Submission Date</th><th>Likes</th><th>Tags</th><th>Edit</th><th>Delete</th>
</tr>
<?php
//include("dbConnection.php");

$n="select * from newsarticle where `editorNo`=$id and `deleted` !=1";
$result=queryDb($n);

if($result!=null){
	$rownum=0;
	while($newsRow=mysqli_fetch_assoc($result)){
		$rownum++;
	
?>
<tr id="<?php echo $newsRow["N_A_no"]?>">
<td><?php echo $rownum;?></td>
<td><?php echo $newsRow["type"];?></td>
<td ><?php echo $newsRow["title"]."</br>";?></td>
<td><?php echo $newsRow["subject"];?></td>
<td><?php echo $newsRow["submissionDate"];?></td>
<td><?php echo $newsRow["likes"];?></td>
<td><?php echo $newsRow["tags"];?></td>

<td > <form style="margin:0;"action="updateNews.php" method="post" ><button type="submit" style="align:center;" class="actionbtn" name="updateNewsNo" onclick=""  value="<?php echo $newsRow["N_A_no"]?>"><img src="icon/update.png"/></button></form></td>
							
<td> <button type="button" class="actionbtn" name="deleteNAno" onclick="deleteNews(this)" value="<?php echo $newsRow["N_A_no"]?>"><img src="icon/delete.png"/></button></td>
</tr>
	<?php }} ?>
