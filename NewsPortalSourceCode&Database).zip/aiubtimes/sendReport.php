<?php

		session_start();
		$id=-1;
		if(isset($_SESSION['user']))
		{	
			if(!$_SESSION['user']=='valid'){
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{
			exit;
		}

		include("dbConnection.php");

if(isset($_REQUEST["news"]) && $id!=-1 && isset($_REQUEST["report"]))
{
	if($_REQUEST["news"]>=0)
	{   $sql="INSERT INTO `report`(`N_A_no`, `report`, `rDate` , `reporterNo`) VALUES (".$_REQUEST["news"].',"'.$_REQUEST["report"].'",NOW(),'.$id.')';
		queryDb($sql);
		//echo $sql;
	}
}

?>