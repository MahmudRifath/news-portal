<?php
			//data extract
			$con = mysqli_connect('localhost','root','');
			mysqli_select_db($con, 'aiub_times');
			include("dbConnection.php");
									
			$sql='SELECT * FROM `newsarticle`,`user_info` WHERE `newsarticle`.`editorNo`=`user_info`.`userNo` and `deleted`!=1 
				and tags like "%home%" ORDER BY `submissionDate` DESC limit 30';
			
			$result = mysqli_query($con, $sql);
			
			$return_arr = array();
			while($row=mysqli_fetch_assoc($result))
			{
				$likes=mysqli_fetch_assoc(queryDb('SELECT count(*) as likes FROM `likesdislikesna` WHERE N_A_no='.$row["N_A_no"]));
				//$likes=$likes["likes"];
				$date=explode(" ",$row["submissionDate"]);
				$return_arr[] = array('<div id="newspart" title="Click To Read" onclick="show(this,\''.ucfirst($row['title']).'\')" class="'.$row["N_A_no"].'">'.
				'<div><b> <p id="newstitle">'
				."<span id='likeSpan".$row["N_A_no"]."' class='Likes'>" .
				'<img id="likesCount" src="icon/likeNo.png">'.$likes["likes"]. "</span>".
				'<span>'.$row['title']."</span>"
				.'</p></b></div> <div id="newscontent">'
				.'<div style=" border-radius:3px; padding-top:2px; width:98%;">'.$row['subject']."<cite id='authercite'>, ".$row["firstName"]." ".$row["lastName"]." ".date_format(date_create($date[0]),"M, d")."</cite> </div>"  
				//.$row['subject']."<cite id='authercite'>, ".$row["firstName"]." ".$row["lastName"]." on ".$date[0]."</cite> " .",<br/>"
				.$row['content']
				.'</div></div>');
			}
			
			echo json_encode($return_arr);
			
			?>
