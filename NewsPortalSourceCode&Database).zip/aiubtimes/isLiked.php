<?php

		session_start();
		$id=-1;
		if(isset($_SESSION['user']))
		{	
			if(!$_SESSION['user']=='valid'){
				//header("location:signin.php");
				//echo "Login for more Options ";
				echo '<a href="signin.php" >Login for more Options </a>';
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{	
			echo '<a href="signin.php">Login for more Options </a>';
			exit;
			//echo "Login for more Options ";
			//header("location:signin.php");
		}

		include("dbConnection.php");

if(isset($_REQUEST["news"]) && $id!=-1)
{
	if($_REQUEST["news"]>=0)
	{
		
		$result= queryDb("select * from `likesdislikesna` where `N_A_no`=".$_REQUEST["news"]." and `likerNo`=".$id);
		//echo "select * from `likesdislikesna` where N_A_no=".$_REQUEST["news"]." and likerNo=".$id;
		$licked=mysqli_fetch_assoc($result);
		if($licked["likerNo"]!=0)
		{
			echo "<img src='icon/dislike.png' />";
		}
		else{
			
			echo "<img src='icon/like.png' />";
		}
	}
}

?>