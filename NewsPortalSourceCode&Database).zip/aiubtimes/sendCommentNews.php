<?php

		session_start();
		$id=-1;
		if(isset($_SESSION['user']))
		{	
			if(!$_SESSION['user']=='valid'){
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{
			exit;
		}

		include("dbConnection.php");

if(isset($_REQUEST["news"]) && $id!=-1 && isset($_REQUEST["comment"]))
{
	if($_REQUEST["news"]>=0)
	{   $sql="INSERT INTO `comments`(`N_A_no`, `comment`, `cDate` , `commenterNo`) VALUES (".$_REQUEST["news"].',"'.$_REQUEST["comment"].'",NOW(),'.$id.')';
		queryDb($sql);
		//echo $sql;
	}
}

?>