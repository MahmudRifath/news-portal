<?php

		session_start();
		$id=-1;
		if(isset($_SESSION['user']))
		{	
			if(!$_SESSION['user']=='valid'){
				header("Location:signin.php");
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{
			header("Location:signin.php");
			exit;
		}

		include("dbConnection.php");

if(isset($_REQUEST["pass"]) && $id!=-1 && isset($_REQUEST["cpass"]))
{
	if($id>=0 && ($_REQUEST["pass"]==$_REQUEST["cpass"]))
	{   $sql='UPDATE `user_info` SET password="'.md5($_REQUEST["pass"]).'" where userNo='.$id;

		queryDb($sql);
		//echo $sql;
		header("Location:signout.php");
	}
	else{
		echo "two password doesnt match or not a valid user";
	}
}
else{
	header("Location:signin.php");
}

?>