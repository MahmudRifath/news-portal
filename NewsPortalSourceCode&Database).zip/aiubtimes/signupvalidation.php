<html>
<head><title>Validation Form</title></head>

<body>

    
	<?php 

    $flag=1;
    
    if(isset($_REQUEST["firstname"])){
		$firstname=$_REQUEST["firstname"];	
	}
	else{
		echo "fill up firstname"."<br/>";
		$flag=0;
	}
	if(isset($_REQUEST["lastname"])){
		$lastname=$_REQUEST["lastname"];
	}
	else{
		echo "fill up lastname"."<br/>";
		$flag=0;
	}
	if(isset($_REQUEST["phone"])){
		$phone=$_REQUEST["phone"];
	}
	else{
		echo "fill up phone"."<br>";
		$flag=0;
	}
	if(isset($_REQUEST["mail"])){
		$mail=$_REQUEST["mail"];
	}
	else{
		echo "fill up mail"."<br/>"; 
		$flag=0;
	}
	if(isset($_REQUEST["password"])){
		$password=$_REQUEST["password"];
	}
	else{
		echo "fill up password"."<br/>";
		$flag=0;
	}
	if(isset($_REQUEST["confirmpassword"])){
		$confirmpassword=$_REQUEST["confirmpassword"];
	}
	else{
		echo "fill up Confirm Password"."<br/>";
		$flag=0;
	}
	if(isset($_REQUEST["gender"])){
		$gender=$_REQUEST["gender"];	
	}
	else{
		echo "Gender Must be Selected"."<br/>";
		$flag=0;
	}
	//print_r($_REQUEST);
	
	if($flag===0){
		exit;
	}
	
	if(strlen($firstname)>0 && strlen($lastname)>0 && strlen($lastname)>0 &&strlen($phone)>0 && strlen($mail)>0 && strlen($password)>0 && strlen($confirmpassword)>0)
	{
		if(preg_match("/^01[0-9]{1}[0-9]{4}[0-9]{4}$/", $phone)
		  && preg_match('/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.* )(?=.*[^a-zA-Z0-9]).{6,16}$/m',$password)
		  ){
			
			if(filter_var($mail, FILTER_VALIDATE_EMAIL)){
				
                
                
				if($password==$confirmpassword && strlen($password)>1){
		
					
					$dob=$_REQUEST["year"]."-".$_REQUEST["month"]."-".$_REQUEST["day"];
					
					$con=mysqli_connect("localhost","root","","aiub_times");
					
					if(!$con){
						die("Connection error");
					}
					
					$alreadyUsed=mysqli_query($con,"select * from `user_info` where `mail`='$mail'");
					//echo "select * from `user_info` where `mail`='$mail'";
					//echo mysqli_num_rows($alreadyUsed);
					
					if(mysqli_num_rows($alreadyUsed) > 0)
					{
						//header("location:editorsSignUp.php");
						echo "This Mail is already Used once and cannot be used again Please go back and provide a valid mail";
						exit;
					}
					
					
					echo "<div align='center'>";
					echo " <fieldset style='width:200px' align='center'><legend>CONFIRMATION</legend>";
					echo "<p>SIGNUP IS COMPLETE</p>"."</br>";
					
                    echo strtoupper($firstname).", ";
					echo strtoupper($lastname)." (".$gender.")"."</br>";
					echo $phone."</br>";
					echo $mail."</br>";
					echo " </fieldset>";
					echo "</div>";
					
					//hashing password
					$password=md5($password);
					//query
					$sql="INSERT INTO `user_info`(`contact`, `DOB`, `gender`, `signUpDate`, `firstName`, `lastName`,`mail`, `password`, `validation`, `usertype`) 
							VALUES ($phone,'$dob','$gender',CURRENT_DATE,'$firstname','$lastname','$mail','$password','valid','visitor')";
					
					//echo $sql;
					if(mysqli_query($con,$sql)){
						header("location:home.php");
						//echo "Inserted";
					}
					else{ //echo "FAILD TO Insert";
					}
					
					
					
					
				}
				else{
					echo "Two password doesnot match or the length shode be more then 6"."<br/>";
				}
			}
			else
				echo "Email is not a valid one"."<br/>";
		}
		else{
			echo "Phone number is not valid or Password is not strong </br>";
		}
	}
	else{
		echo "Please Fill_Up All the Fields </br>";

	}
	?>



</body>
</html>