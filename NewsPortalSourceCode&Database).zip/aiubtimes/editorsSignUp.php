<html>
 <head>
	<title>FORM</title>
     <style>
         #form1{
		 background-color:#e83e263;
             border: 2px solid white;
             margin: 4% 31% 5% 31%;
             width: 38%;
             padding: 0% 0% 2% 0%;
             border-radius: 10px;
         }
		 #in_namef{
            width: 100%;
            height: 25px;
            border-radius: 5px;
            margin-top: 5px;
            outline:none;
              padding-left: 5px;

        }
          #in_namel{
            width: 100%;
            height: 25px;
            border-radius: 5px;
            margin-top: 5px;
            outline:none;
              padding-left: 5px;

        }   
         #align_date{
             padding-top: 6px;
             width: 67%;
              
         }
         #align_gender{
             padding-top: 6px;
             width: 67%;
         }
         #in_sub{
             margin-top: 6px;
             width: 100%;
            height: 33px;
            border-radius: 5px;
            margin-top: 5px;
            background-color: rgb(83, 86, 83);
			color:white;
         }
         #form_table{
             width: 70%;
         }
         #heading{
             font-size: 1.7em;
             margin: 0px 0% -8px 0%;
			 color:white;
             background-color: transparent;
             padding-bottom: 10px;
             padding-top: 10px;
             border-top-left-radius: 20px;
             border-top-right-radius: 20px;
         }
         td{
		 color:white;
		 font-size:1.2em;
		 width:auto;
		 }
		.style_field{
            width: 100%;
            height: 25px;
            border-radius: 5px;
            margin-top: 5px;
            outline:none;
              padding-left: 5px;

        }
		.mark{
		padding-top:8px;
		width:16px;
		}
     </style>
	 
	 <script>
		var check=false;
		var email=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		var passStrong=/^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{6,}$/;
		function generateDay()
		{
			var select=document.getElementById("day");
			var i=0;
			for(i=1;i<=31;i++){
				var option=document.createElement("option");
				option.text=i;
				if(i.toString().length==1)
				option.innerHTML="0"+i;
				else
				option.innerHTML=i;
				select.add(option);
			}
		}
		
		function generateMonth()
		{
			var select=document.getElementById("month");
			var i=0;
			for(i=1;i<=12;i++){
				var option=document.createElement("option");
				if(i.toString().length==1)
				option.innerHTML="0"+i;
				else
				option.innerHTML=i;
				select.add(option);
			}
		}
		function generateYear()
		{
			var select=document.getElementById("year");
			var i=0;
			for(i=new Date().getFullYear();i>=1980;i--){
				var option=document.createElement("option");
				option.text=i;
				option.innerHTML=i;
				select.add(option);
			}
		}
		
		function validate(){
			var error="";
			check=true;
			var flag=true;
			if(document.getElementById("in_namef").value.length<=1){
			error+="Please Give a Valid First Name\n";
			//document.getElementById("in_namef").style.background="#f7a6a0";
			document.getElementById("firstname_mark").src = "icon/error.png";
			flag=false;
			}
			else
			{
			document.getElementById("firstname_mark").src = "icon/checked.png";
			}
			
			if(document.getElementById("in_namel").value.length<=1){
			error+="Please Give a Valid Last Name\n";
			//document.getElementById("in_namel").style.background="#f7a6a0";
			document.getElementById("lastname_mark").src = "icon/error.png";
			flag=false;
			}
			else{document.getElementById("lastname_mark").src = "icon/checked.png";}
			
			
			if(document.getElementById("in_namep").value.length < 11 || document.getElementById("in_namep").value.length > 11 || !document.getElementById("in_namep").value.match(/^\d+$/)){
			error+="Please Give a Valid Phone Number\n";
			//document.getElementById("in_namep").style.background="#f7a6a0";
			document.getElementById("phone_mark").src = "icon/error.png";
			flag=false;
			}
			else{document.getElementById("phone_mark").src = "icon/checked.png";}
			
			
			if(document.getElementById("in_namee").value.length<=1 || !(email.test(document.getElementById("in_namee").value))){
			error+="Please Give a Valid Email\n";
			//document.getElementById("in_namee").style.background="#f7a6a0";
			document.getElementById("email_mark").src = "icon/error.png";
			flag=false;
			}
			else{document.getElementById("email_mark").src = "icon/checked.png";}
			
			if(document.getElementById("male").checked==false && document.getElementById("female").checked==false)
			{
			error+="Gender Must BE Selected\n";
			document.getElementById("gender_mark").src = "icon/error.png";
			flag=false;
			}
			else{document.getElementById("gender_mark").src = "icon/checked.png";}
			
			if(document.getElementById("in_namepw").value.length<=1 || !passStrong.test(document.getElementById("in_namepw").value)){
			error+="Please Give a Valid Password\n"+document.getElementById("in_namepw").value+"   " +document.getElementById("in_namecpw").value+"\n";
			flag=false;
			//document.getElementById("in_namepw").style.background="#f7a6a0";
			//document.getElementById("in_namecpw").style.background="#f7a6a0";
			document.getElementById("pass_mark").src = "icon/error.png";
			document.getElementById("confirmpass_mark").src = "icon/error.png";
			}
			
			else{document.getElementById("pass_mark").src = "icon/checked.png";}
			
			if((document.getElementById("in_namepw").value != document.getElementById("in_namecpw").value) || !(document.getElementById("in_namepw").value.length>2)){
			error+="Two Password does not match\n"+document.getElementById("in_namepw").value+"   " +document.getElementById("in_namecpw").value+"\n";
			flag=false;
			document.getElementById("confirmpass_mark").src = "icon/error.png";
			}
			else{document.getElementById("confirmpass_mark").src = "icon/checked.png";}
			//if(flag==false){alert(error);}
			
			return flag;
		}
		
		function startCheck(){
		check=true;
		}
		setInterval(function (){if(check==true)validate();},300);
		
		
		
	 </script>
	 
	 
 </head>
 <?php include("header.php");?>
 
	<body style="background:url(background/signupbg.jpg); background-size:cover;">
        
			<form action="signupvalidation.php" method="post">
                <div  id="form1">
                    <h3 id="heading" align="center">SignUp</h3><hr/><br/>
				    <table id="form_table" align="center" color="white" width="100%" border="0px">
                        <tr><td>First Name</td><td><input id="in_namef" type="text" name="firstname" onkeypress="startCheck()" /></td><td class="mark" valign="middle"><img title="Can not be empty or greater than two character" alt="" id="firstname_mark" src="" /></td></tr>
                        <tr><td>Last Name</td><td><input id="in_namel" type="text" name="lastname" onkeypress="startCheck()" /></td><td class="mark"  valign="middle" ><img title="Can not be empty or greater than two character" alt="" id="lastname_mark" src="" /></td></tr>
                        <tr><td>DOB</td><td id="align_date" align="center">
                        D
                        <select id="day" name="day" >
                        <script>generateDay();</script>
                        </select>
                        M
                        <select id="month" name="month">
                        <script>generateMonth();</script>
                        </select>
                        Y
                        <select id="year" name="year">
                        <script>generateYear();</script>
                        </select></td>
                        </tr>
                        <tr><td>Gender</td><td id="align_gender" align="center">Male<input onclick="startCheck()"  type="radio" id="male" name="gender" value="male">
                        Female<input onclick="startCheck()" type="radio" id="female" name="gender" value="female"></td><td class="mark" valign="middle"><img alt="" title="Gender must be selected" id="gender_mark" src="" /></td></tr>
                        <tr><td>Phone</td><td><input id="in_namep"  class="style_field"  type="text" name="phone" onkeyup="startCheck()"/></td><td class="mark" valign="middle"><img alt="" title="Phone number must be in 01********* format & must contain 11 digits" id="phone_mark" src="" /></td></tr>
                        <tr><td>Email ID</td><td><input id="in_namee"  class="style_field"  type="text" name="mail" onkeypress="startCheck()"/></td><td class="mark" valign="middle"><img alt="" title="Email must be in example@example.com format" id="email_mark" src="" /></td></tr>


                        <tr><td>Password</td><td><input id="in_namepw" title="Password Must Contain at Least 1-Capital,Small,Special Char and Length >= 6" class="style_field" type="password" name="password" onkeypress="startCheck()"/></td><td class="mark" valign="middle"><img alt="" id="pass_mark" src="" /></td></tr>
                        <tr><td><span style="font-size:.9em;">Confirm Pass<span></td><td><input id="in_namecpw" title="Password Must Contain at Least 1-Capital,Small,Special Char and Length >= 6"  class="style_field"  type="password" name="confirmpassword" onkeypress="startCheck()"/></td><td class="mark" valign="middle"><img alt="" title="Password length must be greater than 5 characters" id="confirmpass_mark" src="" /></td></tr>

                        <tr><td></td><td align="center" style="padding:15px 0px 0px 0px;"><input id="in_sub" type="submit" onclick="return validate();" name="sbt" value="SUBMIT"/></td></tr>
				</table>
                
            </div>
		</form>
	</body>
</html>