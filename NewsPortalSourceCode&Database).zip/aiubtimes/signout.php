<?php
session_start();
	unset($_SESSION["user"]);
	unset($_SESSION["uname"]);
	unset($_SESSION["usertype"]);
	unset($_SESSION["userNo"]);
	unset($_SESSION["photo"]);
	unset($_SESSION["admin"]);
	header("location:home.php");
	
?>