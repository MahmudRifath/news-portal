
<?php
session_start();
		$id=-1;
		if(isset($_SESSION['user']))
		{	
			if(!$_SESSION['user']=='valid'){
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{
			exit;
		}
include("dbConnection.php");

if(isset($_REQUEST["news"]) && $id!=-1 ){
	$result=queryDb('SELECT * FROM `comments` where N_A_no='.$_REQUEST["news"].' and deleted !=1 order by `cDate` desc');
	$arr=array();
	while($row = mysqli_fetch_assoc($result)) {
		$arr[]=$row;
	}
	json_encode($arr);
	$jsn=json_decode(json_encode($arr),true);
	foreach($jsn as $comment){
	
	$name=queryDb('SELECT * FROM `user_info` where userNo='.$comment["commenterNo"]);
	$name=mysqli_fetch_assoc($name);
	$name=ucfirst($name["firstName"])." ".ucfirst($name["lastName"]);

?>

<div class="containerC" >
  <div class="dialogbox">
    <div class="bodyC">
      <div class="message">
        <span><b><?php echo $name." :</b> ".$comment["comment"];?></span>
		<br/><br/> 
		 <?php
			$newsComment='<span class="commentDelete" onclick="deleteComment('.$comment["commentNo"].');" id="commentDelete'.$comment["commentNo"].'">delete</span>'; 
			$editor=queryDb("SELECT * FROM `newsarticle` where N_A_no=".$_REQUEST["news"]." and editorNo=".$id);
			if(mysqli_num_rows($editor)==1)
			{
				$editor=true;
			}
			else
				$editor=false;
		 if($comment['commenterNo']==$id) 
			 echo $newsComment;
		elseif(isset($_SESSION["admin"])){
			if($_SESSION["admin"])
			echo $newsComment;
		}
			
		elseif($editor)
			echo $newsComment;
		 ?> 
		 
		 <span id="commentDate"><?php echo $comment["cDate"]; ?></span>
      
	  </div>
    </div>
  </div>
  </div>
  <?php 
		}
  
	}
?>	