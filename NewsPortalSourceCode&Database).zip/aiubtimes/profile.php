<?php

		session_start();
		if(isset($_SESSION['user']))
		{	
			if(!$_SESSION['user']=='valid'){
				header("location:signin.php");
				exit;
			}
			$id=$_SESSION["userNo"];
		}
		else
		{
			header("location:signin.php");
		}
		?>
<?php include("header.php");?>
<html>
<head>
	<title>User Profile</title>
	<style>
		

		#containerP{
			
			padding: 5px 5px 5px 5px;
			margin: 5% auto 100px auto;
			border: 2px solid gray;
			border-radius: 10px;
			align-content: center;
			width: 30%;
			height: auto;
			font-size:1.3em;
		}
		#tab {
			width:90%;
			padding:0px;
			margin-left:45px;
			border: 0px solid red;
			font-size:1em;
		}
		td{
			text-align:left;
		}
		#tdheadr{
			width:50%;
		}
		#tdinfo{
			width:65%;
		}
		#pp{
			margin:10px 21.5% 10px 21.5%;
			width:200px;
			height:200px;
			border-radius:200px;
			border: 4px solid gray;
		}
		#pp:hover{
			border: 4px solid cyan;
		}
		
		label.filebutton {
			width:120px;
			height:40px;
			overflow:hidden;
			position:relative;
			background-color:#0;
		}

		label span input {
			z-index: 999;
			line-height: 0;
			font-size: 50px;
			position: absolute;
			top: -2px;
			left: -700px;
			opacity: 0;
			filter: alpha(opacity = 0);
			-ms-filter: "alpha(opacity=0)";
			cursor: pointer;
			_cursor: hand;
			margin: 0;
			padding:0;
		}	
			
			#tab2{
			background: #f5f5f5;
			border-collapse: separate;
			box-shadow: inset 0 1px 0 #fff;
			font-size: 12px;
			line-height: 24px;
			margin: 30px auto;
			text-align: left;
			width: 800px;
			}
			#tab2 th{
			background-color :gray;
			color:white;
			font-size:1.2em;
			height: 48px;
			margin: 1px 0 0 0;
			padding-left:5px;
		   }
			#tab2 td{
			font-size:1.1em;
			height: 48px;
			margin: 1px 0 0 0;
			padding-left:5px;
		   }
			
			.actionbtn{
				background:transparent;
				//margin:auto;
			}
			
			#newsInfo{
				<?php 
					if($_SESSION['usertype']=='visitor'){
					echo 'display:none;';
			}
				?>
			}
			
			
			
			.modalReport {
				display: none;
				position: fixed; 
				z-index: 1; 
				padding-top: 50px;
				left: 0;
				top: 0;
				width: 100%; 
				height: 100%; 
				overflow: auto;
				background-color: rgb(0,0,0); 
				background-color: rgba(0,0,0,0.4); 
				
			}
			.modal-content-report {
				background-color: #fefefe;
				margin: auto;
				margin-top:120px;
				margin-bottom:100px;
				overflow-y:auto;
				padding: 20px;
				border: 1px solid #888;
				width: 400px;
				 word-wrap:break-word;
				
			}
			
			.closeReport {
				color: #aaaaaa;
				float: right;
				font-size: 28px;
				font-weight: bold;
				margin-bottom:0px;
			}

			.closeReport:hover,
			.closeReport:focus {
				color: #000;
				text-decoration: none;
				cursor: pointer;
			}
			
	</style>
	
	<script>
	/*	setInterval(function(){
			
			if(document.getElementById("myfile").value.length>2){
				document.getElementById("sbt").style.visibility="visible";
				document.getElementById("pp").src=document.getElementById("myfile").value;
			}
			else
				document.getElementById("sbt").style.visibility="hidden";
			
		},300);
		*/
		var count=0;
		function onFileSelected(event) {
				  var selectedFile = event.target.files[0];
				  var reader = new FileReader();

				  var imgtag = document.getElementById("pp");
				  imgtag.title = selectedFile.name;
				
				  reader.onload = function(event) {
					imgtag.src = event.target.result;
				  };
				count++;  
				document.getElementById("sbt").style.visibility="visible";
				  reader.readAsDataURL(selectedFile);
			}
			
		function deleteNews(newsno){
			if(confirm("Are you sure to Delete ?")){
				var  xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {			
				var m=document.getElementById("tab2");
				m.innerHTML=xmlhttp.responseText;
				}
				};

				var url="deleteNews.php?news="+newsno.value;
				xmlhttp.open("GET", url,true);
				xmlhttp.send();
				
			}
		}
		
		
		function startCheck(){
			var flag=true;
			var passStrong=/^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{6,}$/;
		
			var error="";
			if((!passStrong.test(document.getElementById("in_namepw").value)||document.getElementById("in_namepw").value != document.getElementById("in_namecpw").value) || !(document.getElementById("in_namepw").value.length>2) || !/\S/.test(document.getElementById("in_namepw").value) || !/\S/.test(document.getElementById("in_namecpw").value)){
			error+="Two Password does not match\n"+document.getElementById("in_namepw").value+"   " +document.getElementById("in_namecpw").value+"\n";
			flag=false;
			document.getElementById("in_namecpw").style.background="white url(icon/error.png) no-repeat right ";
			}
			else{document.getElementById("in_namecpw").style.background="white url(icon/checked.png) no-repeat right ";}
			
			return flag;
		}
		
	
	</script>
	
</head>
<body>


<?php 
include("dbConnection.php");

$q="select * from user_info where userNo=".$id;
$result=queryDb($q);
$mail="";
if($result!=null){
	$row=mysqli_fetch_assoc($result);
	
?>			
			

			
			
			
			
			
			
<div id="containerP">

		
<form action="uploadProfile.php" method="post" enctype="multipart/form-data">		
<label class="filebutton">
<img id="pp" align="center" src="<?php echo $row["photo"];?>" alt="profile  image" title="change profile photo">
<span><input type="file" id="myfile" onchange="onFileSelected(event)" name="myfile"></span>
</label>
		
		
<table id="tab">
	<tr>
		<td>Name</td>
		<td id="tdinfo">: <?php echo $row["firstName"]." ".$row["lastName"]."</br>"; ?></td>
	</tr>
	<tr>
		<td>Mail</td>
		<td name="mail">: <?php echo $row["mail"]."</br>";?></td>
	</tr>
	<tr>
		<td>Contact</td>
		<td>: <?php echo $row["contact"]."</br>";?></td>
	</tr>
	<tr>
		<td>DOB</td>
		<td>: <?php echo $row["DOB"]."</br>";?></td>
	</tr>
	<tr>
		<td>Gender</td>
		<td>: <?php echo $row["gender"]."</br>";?></td>
	</tr>
	<tr>
		<td>Signup Date</td>
		<td>: <?php echo $row["signUpDate"]."</br>";?></td>
	</tr>
	<tr>
		<td>User Type</td>
		<td>: <?php echo ucfirst( $row["usertype"])."</br>";?></td>
	</tr>
</table>
	<p style="float:right;margin-top:10px;font-size:.6em;text-decoration:underline;color:red;cursor:pointer;" onclick="passwordPop()"	>Change Password</p>
<div width="150" align="center">
<input type="submit" id="sbt" width="100px" value="save" style="visibility:hidden">
</div>
</form>
</div>	
			
<?php }
?>
		<div id="newsInfo">
					<table id="tab2">
							<tr> 
							<th>NO.</th><th>Type</th><th>Title</th><th>Subject</th><th>Submission Date</th><th>Likes</th><th>Tags</th><th>Edit</th><th>Delete</th>
							</tr>
							<?php
							//include("dbConnection.php");

							$n="select * from newsarticle where `editorNo`=$id and `deleted` !=1 order by `submissionDate` desc";
							$result=queryDb($n);
							if($result!=null){
									$rownum=0;
								while($newsRow=mysqli_fetch_assoc($result)){
								$rownum++;
							?>
							<tr id="<?php echo $newsRow["N_A_no"]?>">

							<td><?php echo $rownum;?></td>
							<td><?php echo $newsRow["type"];?></td>

							<td ><?php echo $newsRow["title"]."</br>";?></td>
							<td><?php echo $newsRow["subject"];?></td>
							<td><?php echo $newsRow["submissionDate"];?></td>
							<td><?php 

								
							$likes=queryDb('SELECT count(*) as "like" FROM `likesdislikesna` WHERE N_A_no ='.$newsRow["N_A_no"]);
							$likes=mysqli_fetch_assoc($likes)["like"];

							echo $likes; ?></td>
							<td><?php echo $newsRow["tags"];?></td>
							
							<td > <form style="margin:0;"action="updateNews.php" method="post" ><button type="submit" style="align:center;" class="actionbtn" name="updateNewsNo" onclick=""  value="<?php echo $newsRow["N_A_no"]?>"><img src="icon/update.png"/></button></form></td>
							
							<td> <button type="button" class="actionbtn" name="deleteNAno" onclick="deleteNews(this)"  value="<?php echo $newsRow["N_A_no"]?>"><img src="icon/delete.png"/></button></td>
							</tr>
								<?php }} ?>
						
					</table>
		</div>
<br/>
<br/>
<br/>
<br/>
<br/>
<div id="reportPop" class="modalReport">

			  <!-- Modal content -->
			  <div class="modal-content-report">
				<span class="closeReport">&times;</span>
				<form action="changePassword.php" method="post">
				<table align="center">
						<tr>
							<td>New Password</td><td><input title="Password Must Contain at Least 1-Capital,Small,Special Char and Length >= 6" id="in_namepw" autocomplete="off" readonly onfocus="this.removeAttribute('readonly');"  type="password" name="pass" onkeyup="startCheck()"/></td>
						</tr>
						<tr>
							<td>Confirm Password</td><td><input title="Password Must Contain at Least 1-Capital,Small,Special Char and Length >= 6" id="in_namecpw" autocomplete="off" readonly onfocus="this.removeAttribute('readonly');"   type="password" name="cpass" onkeyup="startCheck()"/></td>
						</tr>
						<tr>
							<td colspan="2"><input style="margin:5px 0px 2px 50px;width:200px;height:30px;color:white;background:red;" type="submit" value="Confirm" onclick="return startCheck()"/></td>
						</tr>
					</table>
					<br/>
					<br/>
					<span style="color:red;" >* you will be logged out. </span>
				</form>
				
			  </div>

			</div>
<script>

	var modalReport = document.getElementById('reportPop');
	var spanReport = document.getElementsByClassName("closeReport")[0];
	spanReport.onclick = function() {
    modalReport.style.display = "none";
	
		}


		window.onclick = function(event) {
			if (event.target == modalReport) {
				modalReport.style.display = "none";
			}
		}
	
	function passwordPop(){
		modalReport.style.display="block";
	}

</script>
</body>
</html>