<?php 
include("dbConnection.php");

if(isset($_REQUEST["firstName"]) && isset($_REQUEST["lastName"]) && isset($_REQUEST["userType"]) && isset($_REQUEST["mail"]) && isset($_REQUEST["contact"]) && isset($_REQUEST["validation"]) && isset($_REQUEST["gender"]))
{
		$sql=' UPDATE `user_info` SET `contact`= '.$_REQUEST["contact"].',`gender`= "'.$_REQUEST["gender"].'",`firstName`= "'.$_REQUEST["firstName"].'" ,`lastName`= "'.$_REQUEST["lastName"].'",`mail`= "'.$_REQUEST["mail"].'",`validation`="'.$_REQUEST["validation"].'",`usertype`="'.$_REQUEST["userType"].'" WHERE `userNo`= '.$_REQUEST["userNo"];
		//echo $sql;
		queryDb($sql);
}
?>