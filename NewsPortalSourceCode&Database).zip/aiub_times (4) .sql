-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2019 at 11:54 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aiub_times`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `commentNo` int(11) NOT NULL,
  `N_A_no` int(11) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `cDate` datetime NOT NULL,
  `commenterNo` int(11) NOT NULL,
  `deleted` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`commentNo`, `N_A_no`, `comment`, `cDate`, `commenterNo`, `deleted`) VALUES
(1, 2, 'dxnffgkur uefkeviugbh', '2017-11-11 05:04:00', 2, 0),
(2, 2, 'asdadasdasd', '2017-12-07 00:00:00', 2, 0),
(3, 26, 'asd', '2017-12-10 22:15:01', 2, 0),
(4, 26, 'successfull Comment', '2017-12-10 22:15:27', 2, 0),
(5, 26, 'rifath', '2017-12-10 22:16:45', 2, 0),
(6, 24, 'siam', '2017-12-10 22:22:09', 2, 0),
(7, 1, 'very sad', '2017-12-10 22:22:38', 2, 0),
(8, 26, 'tasnim', '2017-12-10 22:24:22', 1, 0),
(9, 1, 'there is nothing to say', '2017-12-10 22:36:30', 1, 0),
(10, 1, 'there is nothing to say', '2017-12-10 22:36:41', 1, 0),
(11, 1, 'there is nothing to say', '2017-12-10 22:36:42', 1, 0),
(12, 26, 'rifath mahmud', '2017-12-10 22:59:23', 1, 0),
(13, 13, 'this is a very nice picture', '2017-12-10 23:17:01', 1, 0),
(14, 13, 'wow', '2017-12-10 23:18:48', 1, 0),
(15, 14, 'i like this post', '2017-12-10 23:20:04', 1, 0),
(16, 14, 'i also like this post', '2017-12-10 23:20:38', 2, 1),
(17, 13, 'test', '2017-12-10 23:21:01', 2, 0),
(18, 13, 'trest', '2017-12-10 23:21:07', 2, 0),
(19, 13, 'test', '2017-12-10 23:21:10', 2, 0),
(20, 1, 'asd', '2017-12-10 23:34:17', 2, 0),
(21, 1, 'asd', '2017-12-10 23:34:47', 2, 0),
(22, 27, 'very good news', '2017-12-11 01:19:54', 1, 0),
(23, 27, 'hello all', '2017-12-11 01:20:13', 1, 0),
(24, 27, 'hello', '2017-12-11 01:20:25', 1, 0),
(25, 27, 'hello', '2017-12-11 01:20:28', 1, 0),
(26, 27, 'hello', '2017-12-11 01:20:31', 1, 0),
(27, 27, 'hello', '2017-12-11 01:20:35', 1, 0),
(28, 27, 'hello to you too', '2017-12-11 01:22:00', 2, 0),
(29, 27, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', '2017-12-11 01:22:17', 2, 0),
(30, 26, 'DASJDNAS', '2017-12-12 10:42:08', 2, 0),
(31, 28, 'jbasjdsabkd', '2017-12-15 01:34:29', 2, 0),
(32, 28, 'again', '2017-12-15 01:34:35', 2, 0),
(33, 1, 'hi rifath', '2017-12-16 00:58:03', 9, 0),
(34, 30, 'sdkjaskd', '2017-12-16 16:19:39', 1, 1),
(35, 27, 'RM', '2017-12-22 00:04:22', 2, 0),
(36, 27, 'test', '2017-12-23 14:56:57', 2, 0),
(37, 27, 'sportsComment', '2017-12-23 15:17:23', 2, 0),
(38, 29, 'tested', '2017-12-23 15:22:04', 1, 0),
(39, 30, '', '2017-12-23 15:22:31', 1, 1),
(40, 29, 'asdasd', '2017-12-23 15:24:56', 1, 0),
(41, 29, '     kll', '2017-12-23 15:28:13', 1, 1),
(42, 31, 'teest', '2017-12-23 16:08:28', 1, 0),
(43, 31, 'hi', '2017-12-23 16:09:25', 2, 0),
(44, 31, 'asd', '2017-12-23 16:19:38', 2, 0),
(45, 31, 'rifath', '2017-12-23 16:19:41', 2, 0),
(46, 31, 'hoeasdasdasdas', '2017-12-23 16:19:46', 2, 1),
(47, 31, ' asd asd', '2017-12-23 16:19:55', 2, 1),
(48, 1, 'waht?', '2017-12-23 16:20:17', 2, 0),
(49, 31, 'rifath mahmud', '2017-12-23 18:39:52', 2, 0),
(50, 32, 'dgtghngj', '2017-12-23 18:56:34', 13, 1),
(51, 32, 'bmkjjk,m', '2017-12-23 18:56:51', 13, 0),
(52, 40, 'good', '2017-12-23 20:20:10', 1, 1),
(53, 29, 'hello', '2017-12-23 22:18:05', 9, 0),
(54, 29, 'this is mine', '2017-12-23 22:18:12', 9, 0),
(55, 40, 'hello', '2017-12-23 22:20:49', 1, 1),
(56, 40, 'asd', '2017-12-23 22:20:51', 1, 1),
(57, 40, 'asd', '2017-12-23 22:21:17', 9, 1),
(58, 40, 'asddsa', '2017-12-23 22:21:20', 9, 0),
(59, 40, 'hekk', '2017-12-23 22:21:22', 9, 1),
(60, 39, 'this is rm', '2017-12-23 22:24:13', 2, 0),
(61, 39, 'ad', '2017-12-23 22:24:15', 2, 0),
(62, 39, 'wow', '2017-12-23 22:24:16', 2, 0),
(63, 39, 'asd', '2017-12-23 22:24:47', 9, 1),
(64, 39, 'asd', '2017-12-23 22:24:47', 9, 0),
(65, 39, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', '2017-12-23 22:24:56', 9, 1),
(66, 39, 'naosdoaindoaind asidnasiodnaond asidnas', '2017-12-23 22:25:05', 9, 0),
(67, 39, 'hi', '2017-12-23 22:28:15', 1, 0),
(68, 40, 'asd', '2017-12-23 22:29:46', 1, 0),
(69, 40, 'dsa', '2017-12-23 22:29:48', 1, 0),
(70, 36, 'asdasd', '2017-12-23 22:29:56', 1, 0),
(71, 36, 'dsa', '2017-12-23 22:29:57', 1, 0),
(72, 36, 'asd', '2017-12-23 22:30:19', 9, 1),
(73, 36, 'dsa', '2017-12-23 22:30:20', 9, 1),
(74, 36, 'as', '2017-12-23 22:30:21', 9, 1),
(75, 36, 'as', '2017-12-23 22:30:22', 9, 1),
(76, 36, 'qe', '2017-12-23 22:30:23', 9, 1),
(77, 36, 'dsa', '2017-12-23 22:30:24', 9, 1),
(78, 36, 'jlasndlad', '2017-12-23 22:30:29', 9, 0),
(79, 36, ';kmdas', '2017-12-23 22:30:30', 9, 1),
(80, 36, 'admin', '2017-12-23 22:31:09', 2, 1),
(81, 36, 'is', '2017-12-23 22:31:12', 2, 0),
(82, 36, 'here', '2017-12-23 22:31:14', 2, 1),
(83, 40, 'jjj', '2017-12-23 23:13:09', 1, 0),
(84, 40, 'hello', '2017-12-23 23:13:33', 1, 0),
(85, 40, 'hi', '2017-12-23 23:13:40', 1, 0),
(86, 40, 'this is asd', '2017-12-23 23:13:49', 1, 0),
(87, 40, 'asd', '2017-12-23 23:15:12', 1, 0),
(88, 40, 'dsa', '2017-12-23 23:15:13', 1, 0),
(89, 40, 'RM', '2017-12-23 23:19:07', 1, 0),
(90, 40, 'yes', '2017-12-23 23:19:12', 2, 0),
(91, 40, 'how are you?', '2017-12-23 23:19:20', 1, 1),
(92, 40, 'I am fine', '2017-12-23 23:19:25', 2, 1),
(93, 40, 'hello?', '2017-12-23 23:19:35', 1, 1),
(94, 25, 'klncd', '2017-12-24 02:37:28', 2, 0),
(95, 25, 'k re', '2017-12-24 02:37:30', 2, 0),
(96, 25, 'kmn asos?', '2017-12-24 02:37:33', 2, 0),
(97, 25, 'helloWorld', '2017-12-24 02:38:16', 9, 0),
(98, 25, 'asd', '2017-12-24 02:38:23', 9, 1),
(99, 25, 'asd', '2017-12-24 02:38:24', 9, 1),
(100, 14, 'asd', '2017-12-24 03:14:48', 2, 0),
(101, 14, 'i also like this one', '2017-12-24 03:14:56', 2, 0),
(102, 40, 'this was a very nice topic', '2019-11-03 23:06:20', 15, 1),
(103, 40, 'Ok', '2019-11-04 00:03:06', 15, 1),
(104, 40, 'ok 1', '2019-11-04 00:03:29', 15, 1),
(105, 41, 'MINE', '2019-11-04 02:46:24', 15, 1),
(106, 37, 'this is test', '2019-11-04 03:08:24', 15, 0),
(107, 41, 'Hell', '2019-11-09 02:57:50', 15, 0);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `name` varchar(50) NOT NULL,
  `newsType` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `ratingWebsite` varchar(50) NOT NULL,
  `ratingSupport` varchar(50) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`name`, `newsType`, `Email`, `gender`, `ratingWebsite`, `ratingSupport`, `comment`) VALUES
('anika', 'Sports News', 'atasnim92@gmail.com', 'female', 'High', 'Good', 'c d'),
('anika', 'Sports News', 'atasnim92@gmail.com', 'female', 'High', 'Very Good', 'hjg'),
('anika', 'Sports News', 'atasnim92@gmail.com', 'female', 'Medium', 'Fair', 'cxvhb'),
('rifath', 'Sports News', 'mahmud@gmail.com', 'male', 'Very High', 'Very Good', 'mahmud'),
('rifath', 'Sports News', 'mahmud@gmail.com', 'male', 'High', 'Average', 'good');

-- --------------------------------------------------------

--
-- Table structure for table `likesdislikesna`
--

CREATE TABLE `likesdislikesna` (
  `LDNo` int(11) NOT NULL,
  `N_A_no` int(11) NOT NULL,
  `likerNo` int(11) NOT NULL,
  `dislikerNo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `likesdislikesna`
--

INSERT INTO `likesdislikesna` (`LDNo`, `N_A_no`, `likerNo`, `dislikerNo`) VALUES
(34, 23, 2, 0),
(36, 24, 1, 0),
(38, 15, 1, 0),
(45, 14, 1, 0),
(49, 26, 2, 0),
(50, 1, 9, 0),
(53, 30, 9, 0),
(57, 28, 2, 0),
(64, 30, 2, 0),
(93, 12, 2, 0),
(97, 29, 2, 0),
(103, 27, 1, 0),
(105, 26, 1, 0),
(107, 28, 1, 0),
(110, 30, 1, 0),
(114, 1, 1, 0),
(115, 31, 1, 0),
(116, 31, 2, 0),
(117, 1, 2, 0),
(118, 32, 13, 0),
(120, 40, 1, 0),
(121, 39, 1, 0),
(122, 36, 1, 0),
(123, 38, 1, 0),
(124, 25, 2, 0),
(125, 25, 9, 0),
(126, 25, 1, 0),
(127, 40, 2, 0),
(129, 38, 2, 0),
(130, 39, 2, 0),
(131, 11, 2, 0),
(137, 37, 15, 0),
(142, 40, 15, 0),
(143, 41, 15, 0),
(144, 36, 15, 0);

-- --------------------------------------------------------

--
-- Table structure for table `newsarticle`
--

CREATE TABLE `newsarticle` (
  `N_A_no` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(80) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `content` varchar(10000) NOT NULL,
  `image` varchar(100) NOT NULL,
  `submissionDate` datetime NOT NULL,
  `editorNo` int(11) NOT NULL,
  `likes` int(11) NOT NULL,
  `dislikes` int(11) NOT NULL,
  `tags` varchar(500) NOT NULL,
  `deleted` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newsarticle`
--

INSERT INTO `newsarticle` (`N_A_no`, `type`, `title`, `subject`, `content`, `image`, `submissionDate`, `editorNo`, `likes`, `dislikes`, `tags`, `deleted`) VALUES
(0, 'Artical', 'asdasd', 'asdasd', '<ol>\r\n	<li><em><strong>asdasdasd</strong></em></li>\r\n	<li><em><strong>asd</strong></em></li>\r\n	<li><em><strong>asd</strong></em></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li><em><strong>asdsa</strong></em>\r\n\r\n	<ul>\r\n		<li><em><strong>&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;asd</strong></em>\r\n\r\n		<ul>\r\n			<li><em><strong>&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;asda</strong></em>\r\n\r\n			<ul>\r\n				<li><em><strong>&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;&#8203;asd</strong></em></li>\r\n			</ul>\r\n			</li>\r\n		</ul>\r\n		</li>\r\n	</ul>\r\n	</li>\r\n</ul>\r\n', 'news/', '2017-11-27 22:17:30', 1, 0, 0, '@home', 0),
(1, 'News', 'Road Accident', 'Accident', 'Bangladesh is a very populated country. Here road management is very bad. Every day we find road accident news in daily newspapers. I also face a road accident. Everyday go my college by local bus. Like daily activities I was going for my bus. I was standing on the rod and waiting for the bus. Then I saw two little boys are crossing the busy road. They were not enough to cross the road. When they are crossing the road a bus push them in little speed. They were very afraid for his and they also little injured. One boy\'s leg was injured and another was injured in his hand. I rushed them and treatment them. I took a medicine from the nearby dispensary and used it on the injured place. They are crying for pain. I told them where from they are and where hey want to go.', '', '2017-11-09 00:00:00', 1, 0, 0, '@home@accident', 0),
(9, 'News', 'sdfsdf', 'asdasda', '&lt;p&gt;dpifjpsdifjs&lt;/p&gt;\r\n', 'news/', '2017-11-28 00:30:58', 1, 0, 0, '@home', 0),
(10, 'News', 'sdfsdf', 'asdasda', '<h1>dpifjpsdifjs</h1>\r\n\r\n<div style=\"background:#eeeeee; border:1px solid #cccccc; padding:5px 10px\">as;ldmas;ldmasl;das</div>\r\n\r\n<div style=\"background:#eeeeee; border:1px solid #cccccc; padding:5px 10px\">dasdlmas;mdal;smda</div>\r\n\r\n<div style=\"background:#eeeeee; border:1px solid #cccccc; padding:5px 10px\">dasl;da;slmd;sadas</div>\r\n\r\n<div style=\"background:#eeeeee; border:1px solid #cccccc; padding:5px 10px\">a;kmdasmd;lasm</div>\r\n\r\n<ol>\r\n	<li>asdasdasd</li>\r\n	<li>as</li>\r\n	<li>das</li>\r\n	<li>das</li>\r\n	<li>d&nbsp;</li>\r\n</ol>\r\n\r\n<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:500px\">\r\n	<tbody>\r\n		<tr>\r\n			<td>asdasdasdasdasda</td>\r\n			<td>asdasdasdasdsada</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<blockquote>\r\n<p>&nbsp;asdadasdasdad</p>\r\n\r\n<p>asdasdadsdasd</p>\r\n</blockquote>\r\n\r\n<h2><span class=\"marker\"><em>asdasdasdadaasdasd</em>&nbsp;</span></h2>\r\n', 'news/', '2017-11-28 00:33:44', 1, 0, 0, '@home@sports', 0),
(11, 'News', 'ASDASD', 'ASDAD', '<p><img alt=\"\" src=\"/PostNewsPHP/D_11.23.2017_V_0.5/kcfinder/upload/images/mountain-night-sky-milky-way.jpg\" style=\"float:right; height:100px; width:160px\" />thIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDAthIS IS A TESDASDA</p>\r\n', 'news/', '2017-11-30 21:16:52', 1, 0, 0, '@home@weather', 0),
(12, 'News', 'delete', 'asd', '<p>asdasd</p>\r\n\r\n<p>asdasd</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;asda&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;asdsada asssssssssssas&nbsp;</p>\r\n\r\n<p>assssssssssss&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; asdasd</p>\r\n', 'news/', '2017-11-30 21:22:10', 1, 0, 0, '@home@sports@weather@accident', 0),
(15, 'News', 'test', 'test', '<p>test</p>\r\n', 'news/', '2017-12-07 21:40:24', 2, 0, 0, '@home', 0),
(23, 'News', 'aa', 'aa', '<p>aa</p>\r\n', '', '2017-12-09 00:12:14', 2, 0, 0, '@home', 0),
(24, 'News', 'aa', 'aaa', '<p>aaa</p>\r\n', '', '2017-12-09 00:46:41', 2, 0, 0, '@home@sports@weather', 0),
(25, 'Article', 'dvrgbt', 'fbng', '<p>vfg h</p>\r\n', '', '2017-12-24 04:06:06', 1, 0, 0, '@home@sports', 1),
(26, 'News', 'Weather', 'weather', '<p>asdasd</p>\r\n', '', '2017-12-10 03:10:47', 2, 0, 0, '@home@weather', 0),
(27, 'News', 'Sports', 'new game on town', '<p>new game on town</p>\r\n', '', '2017-12-10 23:49:54', 2, 0, 0, '@home@sports', 0),
(28, 'Article', 'artical test updated cheked again', 'artical test', '<p>artical testartical testartical testartical test</p>\r\n\r\n<p>artical testartical testartical testartical testartical testartical test</p>\r\n\r\n<p>artical testartical testartical testartical testartical testartical test</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>testedartical test updated chekedartical test updated chekedartical test updated cheked</p>\r\n\r\n<p>artical test updated chekedartical test updated cheked</p>\r\n\r\n<p>artical test updated cheked</p>\r\n', '', '2017-12-15 00:10:47', 2, 0, 0, '@home@sports', 0),
(29, 'News', 'TEST FOR DELETE', 'aa', '<p>aaaibbiunuiniupbyvgyug</p>\r\n\r\n<p>o bgoyih[=</p>\r\n\r\n<p>ppuuy[n0-</p>\r\n\r\n<p>nhiohn jmij</p>\r\n', '', '2017-12-15 02:49:04', 2, 0, 0, '@home@sports', 0),
(30, 'Article', 'bj', 'hkvbkh', '<p>hjvjhv</p>\r\n', '', '2017-12-16 16:15:15', 1, 0, 0, '@home@technology@literature', 0),
(31, 'News', 'other', 'other', '<p>other Section</p>\r\n', '', '2017-12-23 14:32:32', 2, 0, 0, '@home@sports@weather@others', 0),
(32, 'News', 'vcnjgj', 'hjnhnj', '<p>fhnn fxhj k.</p>\r\n', '', '2017-12-23 18:53:06', 13, 0, 0, '@home@sports@others', 1),
(33, 'News', 'IBM cognitive computing system', 'Greg Otto at fedscoop wrote this interesting piece about IBMâ€™s Watson-as-a-Service.', '<p>IBM&nbsp;announced last week it has moved its cognitive computing system into the cloud to form the Watson Discovery Advisor, allowing researchers, academics and anyone else trying to leverage big data the ability to test programs and hypotheses at speeds never before seen.</p>\r\n\r\n<p>Since Watson is built to understand the nuance of natural language, this new service allows researchers to process millions of data points normally impossible for humans to handle. This can reduce project timelines from years to weeks or days.</p>\r\n', '', '2017-12-23 19:04:07', 1, 0, 0, '@home@technology@others', 0),
(34, 'News', 'The Evaluation of Exercise-Induced Hematuria in En', 'The Evaluation of Exercise-Induced Hematuria in Endurance Athletes', '<p>Microscopic hematuria can be defined as the presence of greater (&gt;) than 3 red blood cells per milliliter (mL) detected on a high-powered microscopic field, or &gt; 50 red blood cells per mL of urine present on a urine dipstick (14). Exercise-induced hematuria in healthy young adults is not usually associated with significant morbidity or mortality (15). Moderate exercise-induced hematuria is seen habitually, both in athletes and in the general public (14). However, hematuria can be a signal of more serious diseases (15). In endurance athletes, the microscopic hematuria is often self-limiting and resolves within 48-72 hours (1). The abnormal presence of red blood cells in urine may indicate kidney inflammation, infection or trauma in the urinary tract, or neoplastic diseases in the urogenital tract (6). If hematuria doesn&rsquo;t resolve within 48-72 hours, providers should consider further evaluation. Diagnostics and interventions should be adapted to the individual based on the history of present illness, age, and past medical history. Future research on this topic could be adapted to evaluating and treating microscopic hematuria in multiple sports and activities.</p>\r\n', '', '2017-12-23 19:08:33', 1, 0, 0, '@home@sports@literature', 0),
(35, 'News', 'Examining the spatiotemporal dynamics of meteorolo', 'A case study in Woleka sub-basin', '<p>Examining the spatiotemporal dynamics of meteorological variables in the context of changing climate, particularly in countries where rainfed agriculture is predominant, is vital to assess climate-induced changes and suggest feasible adaptation strategies. To that end, trend analysis has been employed to inspect the change of rainfall and temperature in northcentral Ethiopia using gridded monthly precipitation data obtained from Global Precipitation and Climate Centre (GPCC V7) and temperature data from Climate Research Unit (CRU TS 3.23) with 0.5&deg; by 0.5&deg; resolution from 1901 to 2014. Data have been analyzed using coefficient of variation, anomaly index, precipitation concentration index and Palmer drought severity index. Furthermore, Mann-Kendall test was used to detect the time series trend. The result revealed intra- and inter-annual variability of rainfall while Palmer drought severity index value proved the increasing trend of the number of drought years. Annual, belg and kiremt rainfall have decreased with a rate of 15.03, 1.93 and 13.12â€¯mm per decade respectively. The declining trend for annual and kiremt rainfall was found to be statistically significant while that of belg was not significant. The rate of change of temperature was found to be 0.046, 0.067 and 0.026 â€¯&deg;C per decade for mean, minimum and maximum respectively. The Mann-Kendall trend analysis test result revealed increasing trend for mean and minimum average temperatures through time significantly while the trend for maximum temperature exhibited a non-significant increasing trend. We recommend strategies designed in the agricultural sector have to take the declining and erratic nature of rainfall and increasing trend of temperature into consideration.</p>\r\n', '', '2017-12-23 19:14:50', 1, 0, 0, '@home@weather', 1),
(36, 'News', 'Variability and time series trend analysis of rainfall and temperature in northc', 'A case study in Woleka sub-basin', '<p>Examining the spatiotemporal dynamics of meteorological variables in the context of changing climate, particularly in countries where rainfed agriculture is predominant, is vital to assess climate-induced changes and suggest feasible adaptation strategies. To that end, trend analysis has been employed to inspect the change of rainfall and temperature in northcentral Ethiopia using gridded monthly precipitation data obtained from Global Precipitation and Climate Centre (GPCC V7) and temperature data from Climate Research Unit (CRU TS 3.23) with 0.5&deg; by 0.5&deg; resolution from 1901 to 2014. Data have been analyzed using coefficient of variation, anomaly index, precipitation concentration index and Palmer drought severity index. Furthermore, Mann-Kendall test was used to detect the time series trend. The result revealed intra- and inter-annual variability of rainfall while Palmer drought severity index value proved the increasing trend of the number of drought years. Annual, belg and kiremt rainfall have decreased with a rate of 15.03, 1.93 and 13.12â€¯mm per decade respectively. The declining trend for annual and kiremt rainfall was found to be statistically significant while that of belg was not significant. The rate of change of temperature was found to be 0.046, 0.067 and 0.026 â€¯&deg;C per decade for mean, minimum and maximum respectively. The Mann-Kendall trend analysis test result revealed increasing trend for mean and minimum average temperatures through time significantly while the trend for maximum temperature exhibited a non-significant increasing trend. We recommend strategies designed in the agricultural sector have to take the declining and erratic nature of rainfall and increasing trend of temperature into consideration.</p>\r\n', '', '2017-12-23 19:22:35', 1, 0, 0, '@home@weather', 0),
(37, 'News', 'Technology is changing disaster relief.', 'Consider the efforts of the United Kingdomâ€™s Royal Air Force', '<p>Alongside tents and drinking water, RAF planes dropped more than 1,000 solar-powered lanterns attached to chargers for all types of mobile handsets to the stranded members of the Yazidi religious community below.</p>\r\n\r\n<p>It is the first time the lanterns have been airdropped in such a relief effort, but humanitarian workers say it is part of growing efforts to develop technology designed to make a difference in disaster zones.</p>\r\n', '', '2017-12-23 19:32:45', 2, 0, 0, '@home@technology@literature', 0),
(38, 'News', 'Examining Physical Activity and Affect Using Objective Measures', ' A Pilot Study of Anorexia Nervosa', '<p>This pilot study used accelerometers and ecological momentary assessment (EMA) to objectively examine physical activity and affect among women suffering from anorexia nervosa (AN). Nine women with AN wore ActiGraphTM accelerometers and completed EMA recordings across seven days. Mixed-effects linear models revealed temporal associations between physical activity and affect within the same day, within the same hour, and within the next hour. Momentary measurement of physical activity and positive affect revealed reciprocal effects, in that physical activity enhanced positive affect, which in turn, facilitated further activity. Findings reflect the utility of objective assessment measures in real time for the link between physical activity and affect among women with AN. The implementation of a tailored physical activity program, coordinated by trained clinical and sports professionals, may be a valuable asset for the treatment of AN.</p>\r\n', '', '2017-12-23 19:36:01', 2, 0, 0, '@home@sports@others', 0),
(39, 'News', 'Extreme temperature differences in the city of Lahti, southern Finland', 'Intensity, seasonality and environmental drivers', '<p>The extremes of month-specific spatial temperature differences were studied for a first time in the high-latitude city of Lahti and its surroundings in southern Finland. During the 2-year observation period (6/14&ndash;5/16), the largest momentary temperature difference, 11.1&nbsp;&deg;C, was detected in February, and the smallest, 6.2&nbsp;&deg;C, in April. The impacts of various environmental factors during the extreme situations were estimated by site-specific analysis of the warmest and coldest observation sites and a stepwise multiple linear regression model including all the 8 observation sites. The extreme temperature differences were characterised by inversions especially in winter and spring, the warmest site being the hill-top location in Kivist&ouml;nm&auml;ki. In summer the role of urban heating was more apparent, and the temperature was the highest in the relatively low-lying city centre. In autumn the heating impact of the relatively warm Lake Vesij&auml;rvi caused the largest temperature differences with harbour as the warmest site. The weather during all of the momentary extreme situations was calm and in the majority of the situations also clear. The impact of cloud cover was less critical than that of wind speed in reducing spatial temperature differences. The momentary extreme situations existed at night or at dawn, with one exception: only in January, during the cold weather period dominated by high pressure, the delayed break of inversion in the vicinity of Lake Vesij&auml;rvi caused the extreme temperature difference to exist in the afternoon, reflecting for its part the substantial stabilising impact of seasonal ice cover on Lake Vesij&auml;rvi.</p>\r\n', '', '2017-12-23 19:37:31', 2, 0, 0, '@home@weather', 0),
(40, 'News', 'Identification of significant factors in fatal-injury highway crashes using gene', 'This study provides insights on the injury pattern of highway crashes.', '<p>Identification of the significant factors of traffic crashes has been a primary concern of the transportation safety research community for many years. A fatal-injury crash is a comprehensive result influenced by multiple variables involved at the moment of the crash scenario, the main idea of this paper is to explore the process of significant factors identification from a multi-objective optimization (MOP) standpoint. It proposes a data-driven model which combines the Non-dominated Sorting Genetic Algorithm (NSGA-II) with the Neural Network (NN) architecture to efficiently search for optimal solutions. This paper also defines the index of Factor Significance (Fs) for quantitative evaluation of the significance of each factor. Based on a set of three year data of crash records collected from three main interstate highways in the Washington State, the proposed method reveals that the top five significant factors for a better Fatal-injury crash identification are 1) Driver Conduct, 2) Vehicle Action, 3) Roadway Surface Condition, 4) Driver Restraint and 5) Driver Age. The most sensitive factors from a spatiotemporal perspective are the Hour of Day, Most Severe Sobriety, and Roadway Characteristics. The method and results in this paper provide new insights into the injury pattern of highway crashes and may be used to improve the understanding of, prevention of, and other enforcement efforts related to injury crashes in the future.</p>\r\n', '', '2017-12-23 19:39:32', 2, 0, 0, '@home@accident@technology', 0),
(41, 'News', 'Real-Time Face Detection', 'Computer Vision', '<h1>A new approach</h1>\r\n', '', '2019-11-04 01:44:05', 15, 0, 0, '@home@technology@literature@others', 0),
(42, 'News', 'Rotate test', 'Test', '<p>Working</p>\r\n', '', '2019-11-09 04:45:54', 15, 0, 0, '@home@sports', 0),
(43, 'News', 'Rotate test 1', 'Test', '<p>Test1</p>\r\n', '', '2019-11-09 04:54:03', 15, 0, 0, '@home@others', 0),
(44, 'News', 'Posted from tab', 'Refresh check', '<p>This is posted from tab</p>\r\n', '', '2019-11-09 20:54:45', 15, 0, 0, '@home@others', 0),
(45, 'News', 'Real-Time Face Detection', 'Computer Vision', '<p>asdasdasd</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>asd</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>asd</p>\r\n\r\n<p>asd</p>\r\n\r\n<p><img alt=\"\" src=\"/aiubtimes/kcfinder/upload/images/signupbg.jpg\" style=\"height:141px; width:250px\" /></p>\r\n', '', '2019-11-10 01:54:25', 15, 0, 0, '@home@others', 0),
(46, 'News', 'Background Test', 'Background', '<h3><big>This New Version of AIUB TIMES looks Great!!</big></h3>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><img alt=\"\" src=\"/aiubtimes/kcfinder/upload/images/cosmos-nebula-galaxy-triangle%20(1).jpg\" style=\"height:169px; width:300px\" /></p>\r\n', '', '2019-11-10 03:25:20', 15, 0, 0, '@home@technology', 0),
(47, 'News', 'BULBUL STRIKES', 'cyclone', '<p>Cyclone Warning for Northwest Bay of Bengal&nbsp;The Very Severe Cyclonic Storm &lsquo;Bulbul&rsquo; (Pronounced as Bul bul) over northwest Bay of Bengal moved northeastwards with a speed of 11 kmph during past 06 hours, weakened into</p>\r\n\r\n<p><img alt=\"\" src=\"/aiubtimes/kcfinder/upload/images/Bulbul-atelite.jpg\" style=\"height:188px; width:300px\" /></p>\r\n', '', '2019-11-10 04:41:34', 15, 0, 0, '@home@weather', 0);

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `reportNo` int(11) NOT NULL,
  `N_A_no` int(11) NOT NULL,
  `report` varchar(2000) NOT NULL,
  `rDate` datetime NOT NULL,
  `reporterNo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`reportNo`, `N_A_no`, `report`, `rDate`, `reporterNo`) VALUES
(1, 30, 'test report', '2017-12-23 06:17:29', 2),
(2, 30, 'this is not ok', '2017-12-23 06:18:31', 1),
(3, 28, 'test artical report', '2017-12-23 14:18:04', 2),
(4, 28, 'i dont like it', '2017-12-23 14:30:36', 2),
(5, 29, 'ljblbl', '2017-12-23 15:47:58', 1),
(6, 30, 'not', '2017-12-23 15:48:36', 1),
(7, 30, 'asdasd', '2017-12-23 15:49:02', 1),
(8, 29, 'asdasdsa', '2017-12-23 15:50:30', 1),
(9, 29, 'check', '2017-12-23 15:50:44', 1),
(10, 31, 'asdasdasdasd', '2017-12-23 18:40:09', 2),
(11, 31, 'other is not ok', '2017-12-23 18:41:24', 2),
(12, 32, 'zsgdfhgnh', '2017-12-23 18:57:18', 13),
(13, 40, 'Identification of significant factors in fatal-injury highway crashes using gene', '2017-12-24 02:45:53', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `tagNo` int(11) NOT NULL,
  `tagName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`tagNo`, `tagName`) VALUES
(1, 'sports'),
(2, 'weather'),
(3, 'accident'),
(4, 'technology'),
(5, 'literature'),
(6, 'others');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `userNo` int(11) NOT NULL,
  `contact` int(11) NOT NULL,
  `DOB` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `signUpDate` date NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `validation` varchar(10) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `photo` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`userNo`, `contact`, `DOB`, `gender`, `signUpDate`, `firstName`, `lastName`, `mail`, `password`, `validation`, `usertype`, `photo`) VALUES
(1, 1714339669, '1996-10-02', 'female', '2019-10-29', 'Anika', 'Tasnim', 'tasnim@gmail.com', '448ddd517d3abb70045aea6929f02367', 'valid', 'editor', 'profile/1.jpg'),
(2, 1534580001, '1996-01-16', 'male', '2019-10-29', 'Rifath', 'Mahmud', 'mahmud@gmail.com', '0e7517141fb53f21ee439b355b5a1d0a', 'valid', 'admin', 'profile/2.jpg'),
(13, 1515687101, '1995-04-28', 'female', '2019-10-29', 'Ashrafi', 'Hossain', 'ashrafi@gmail.com', '448ddd517d3abb70045aea6929f02367', 'valid', 'editor', 'profile/13.jpg'),
(15, 1617449246, '1996-10-15', 'male', '2019-11-03', 'Mahmud', 'Rifath', 'mahmudrifath345@gmail.com', '6748f220315827f081517348ef787f19', 'valid', 'admin', 'profile/15.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentNo`);

--
-- Indexes for table `likesdislikesna`
--
ALTER TABLE `likesdislikesna`
  ADD PRIMARY KEY (`LDNo`);

--
-- Indexes for table `newsarticle`
--
ALTER TABLE `newsarticle`
  ADD PRIMARY KEY (`N_A_no`) USING BTREE,
  ADD KEY `dislikes` (`dislikes`) USING BTREE,
  ADD KEY `likes` (`likes`) USING BTREE;

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`reportNo`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`tagNo`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`userNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `commentNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `likesdislikesna`
--
ALTER TABLE `likesdislikesna`
  MODIFY `LDNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;

--
-- AUTO_INCREMENT for table `newsarticle`
--
ALTER TABLE `newsarticle`
  MODIFY `N_A_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `reportNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `tagNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `userNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
